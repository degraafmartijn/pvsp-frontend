import axios from 'axios'

// All requests go through Vite's proxy /api → http://localhost:8000
const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// ── Dashboard ───────────────────────────────────────────────────
export const fetchSummary      = ()       => api.get('/dashboard/summary').then(r => r.data)

// ── Vendors ─────────────────────────────────────────────────────
export const fetchVendors      = (params) => api.get('/vendors', { params }).then(r => r.data)
export const fetchVendor       = (id)     => api.get(`/vendors/${id}`).then(r => r.data)
export const createVendor      = (data)   => api.post('/vendors', data).then(r => r.data)
export const updateVendor      = (id, d)  => api.patch(`/vendors/${id}`, d).then(r => r.data)
export const deleteVendor      = (id)     => api.delete(`/vendors/${id}`)

// ── Contracts ───────────────────────────────────────────────────
export const fetchContracts    = (vid)    => api.get(`/vendors/${vid}/contracts`).then(r => r.data)
export const createContract    = (vid, d) => api.post(`/vendors/${vid}/contracts`, d).then(r => r.data)

// ── Compliance ──────────────────────────────────────────────────
export const fetchCompliance   = (vid)    => api.get(`/vendors/${vid}/compliance`).then(r => r.data)
export const upsertCompliance  = (vid, d) => api.put(`/vendors/${vid}/compliance`, d).then(r => r.data)

// ── Health metrics ──────────────────────────────────────────────
export const fetchHealth       = (vid, limit = 12) => api.get(`/vendors/${vid}/health`, { params: { limit } }).then(r => r.data)
export const recordHealth      = (vid, d) => api.post(`/vendors/${vid}/health`, d).then(r => r.data)

// ── Meetings ────────────────────────────────────────────────────
export const fetchMeetings     = (vid)    => api.get(`/vendors/${vid}/meetings`).then(r => r.data)
export const createMeeting     = (vid, d) => api.post(`/vendors/${vid}/meetings`, d).then(r => r.data)
export const fetchAllMeetings  = ()       => api.get('/vendors').then(async r => {
  const all = await Promise.all(r.data.map(v => fetchMeetings(v.id)))
  return all.flat()
})

// ── Risk log ────────────────────────────────────────────────────
export const fetchRisks        = (params) => api.get('/risks', { params }).then(r => r.data)
export const updateRisk        = (id, d)  => api.patch(`/risks/${id}`, d).then(r => r.data)
export const createRisk        = (vid, d) => api.post(`/vendors/${vid}/risks`, d).then(r => r.data)

// ── Tasks ───────────────────────────────────────────────────────
export const fetchTasks        = (params) => api.get('/tasks', { params }).then(r => r.data)
export const createTask        = (data)   => api.post('/tasks', data).then(r => r.data)
export const updateTask        = (id, d)  => api.patch(`/tasks/${id}`, d).then(r => r.data)
export const deleteTask        = (id)     => api.delete(`/tasks/${id}`)

// ── Renewal ─────────────────────────────────────────────────────
export const fetchRenewalFunnel   = ()    => api.get('/renewal/funnel').then(r => r.data)
export const fetchExpiringContracts = (days = 90) => api.get('/renewal/expiring', { params: { days } }).then(r => r.data)

// ── Domains ─────────────────────────────────────────────────────
export const fetchDomains      = ()       => api.get('/domains').then(r => r.data)
export const createDomain      = (data)   => api.post('/domains', data).then(r => r.data)

// ── AI ──────────────────────────────────────────────────────────
export const analyzeContract   = (text)   => api.post('/ai/analyze-contract', { text }).then(r => r.data)

export default api
