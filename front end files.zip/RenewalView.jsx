import { useRenewalFunnel, useExpiringContracts } from '@/hooks/useVendors'
import { Card, SectionHeader, Badge } from '@/components/ui'
import { fmtEur, daysLeft } from '@/lib/utils'

const STAGES = [
  { key:'t12', label:'T-12 maanden', title:'Performance Review',    role:'Systeem / AI',       color:'#154273' },
  { key:'t9',  label:'T-9 maanden',  title:'Behoefte Validatie',    role:'Product Owner',       color:'#077a8a' },
  { key:'t6',  label:'T-6 maanden',  title:'Beslissing',            role:'Contract Manager',    color:'#d97706' },
  { key:'t3',  label:'T-3 maanden',  title:'Juridische Deadline',   role:'Contract Eigenaar',   color:'#c0392b' },
]

const DECISIONS = {
  handmatig:   { label:'Handmatig', color:'#154273' },
  automatisch: { label:'Automatisch', color:'#1a9e5c' },
  eenmalig:    { label:'Eenmalig', color:'#d97706' },
}

export default function RenewalView() {
  const { data: funnel = {} } = useRenewalFunnel()
  const { data: expiring = [] } = useExpiringContracts(365)

  return (
    <div className="max-w-[940px]">
      {/* Funnel steps */}
      <div className="grid grid-cols-4 gap-0 mb-6 relative">
        {STAGES.map((s, idx) => {
          const contracts = funnel[s.key] || []
          return (
            <div
              key={s.key}
              className={`bg-white border border-gray-200 p-4 relative ${idx === 0 ? 'rounded-l-xl' : ''} ${idx === 3 ? 'rounded-r-xl border-l-0' : 'border-r-0'}`}
            >
              <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1">{s.label}</div>
              <div className="text-[12px] font-bold text-gray-900 mb-1">{s.title}</div>
              <div className="text-[10px] text-gray-500 leading-snug mb-3">
                {s.key === 't12' && 'AI genereert performance review op basis van VHS historiek.'}
                {s.key === 't9'  && 'Product Owner valideert functionele behoefte voor de toekomst.'}
                {s.key === 't6'  && 'Contract Manager kiest: verlengen, heraanbesteden of beëindigen.'}
                {s.key === 't3'  && 'Juridische opzegtermijn. Geen actie → escalatie naar CE.'}
              </div>
              <Badge color={s.color}>{s.role}</Badge>
              {contracts.length > 0 && (
                <div className="mt-2 flex flex-col gap-1.5">
                  {contracts.map(c => (
                    <div key={c.id} className="bg-gray-50 rounded-lg px-2.5 py-1.5 flex justify-between text-[10px]">
                      <span className="font-semibold" style={{ color: s.color }}>{c.contract_name?.split(' ')[0]}</span>
                      <span className="text-gray-400">{fmtEur(c.total_value)}</span>
                    </div>
                  ))}
                </div>
              )}
              {idx < 3 && (
                <div className="absolute right-[-12px] top-1/2 -translate-y-1/2 z-10 w-0 h-0"
                  style={{ borderLeft: `12px solid ${s.color}30`, borderTop: '10px solid transparent', borderBottom: '10px solid transparent' }} />
              )}
            </div>
          )
        })}
      </div>

      {/* Contracts table */}
      <SectionHeader title="Contracten in Renewal Traject" />
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-card">
        <table className="w-full border-collapse text-[11px]">
          <thead>
            <tr className="bg-gov-light">
              {['Contract','Einddatum','Waarde','Opzegtermijn','Type Verlenging','Getekend'].map(h => (
                <th key={h} className="text-left px-3.5 py-2.5 text-gov font-bold text-[10px] uppercase tracking-wider border-b border-gray-200">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {expiring.map(c => {
              const days = daysLeft(c.end_date)
              return (
                <tr key={c.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="px-3.5 py-2.5 font-semibold">{c.contract_name}</td>
                  <td className="px-3.5 py-2.5" style={{ color: days <= 90 ? '#c0392b' : undefined, fontWeight: days <= 90 ? 700 : 400 }}>
                    {c.end_date} <span className="text-gray-400 font-normal">({days > 0 ? `${days}d` : 'verlopen'})</span>
                  </td>
                  <td className="px-3.5 py-2.5 font-mono">{fmtEur(c.total_value)}</td>
                  <td className="px-3.5 py-2.5">{c.notice_period}d</td>
                  <td className="px-3.5 py-2.5">
                    <Badge color={DECISIONS[c.renewal_type]?.color || '#154273'}>{c.renewal_type}</Badge>
                  </td>
                  <td className="px-3.5 py-2.5">
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${c.signature_status ? 'bg-green-bg text-green' : 'bg-red-bg text-red'}`}>
                      {c.signature_status ? '✓ Getekend' : '✗ Ontbreekt'}
                    </span>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
