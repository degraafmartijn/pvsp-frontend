import { useState } from 'react'
import { Zap } from 'lucide-react'
import { useVendors } from '@/hooks/useVendors'
import { analyzeContract } from '@/api/client'
import { Card, Textarea, Select, Button, Spinner, Badge } from '@/components/ui'
import { vName, fmtEur } from '@/lib/utils'

function AICard({ title, sub, color, desc, children }) {
  return (
    <Card className="overflow-hidden flex flex-col">
      <div className="px-4 py-3.5 flex items-start gap-2.5" style={{ background: color }}>
        <div>
          <div className="text-white font-syne text-[13px] font-bold">{title}</div>
          <div className="text-white/65 text-[10px] mt-0.5">{sub}</div>
        </div>
        <div className="ml-auto bg-white/20 text-white text-[8px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0">Mock AI</div>
      </div>
      <div className="p-4 flex-1 flex flex-col gap-3">
        <div className="text-[10px] text-gray-600 leading-relaxed">{desc}</div>
        {children}
      </div>
    </Card>
  )
}

// ── Clause Analyzer ───────────────────────────────────────────────
function ClauseAnalyzer() {
  const [text, setText]     = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoad]  = useState(false)

  const run = async () => {
    if (!text.trim()) return
    setLoad(true)
    try {
      const r = await analyzeContract(text)
      setResult(r)
    } finally {
      setLoad(false)
    }
  }

  return (
    <AICard title="AI Clause Analyzer" sub="GIBIT / ARBIT compliance check" color="#154273"
      desc="Vergelijkt contractclausules met GIBIT of ARBIT standaarden en markeert afwijkingen.">
      <Textarea label="Contractclausule (plak tekst)"
        placeholder='Bijv: "Leverancier heeft het recht om de dienstverlening eenzijdig te wijzigen…"'
        value={text} onChange={e => setText(e.target.value)} />
      <Button onClick={run} disabled={loading} className="self-start">
        {loading ? <><Spinner size={13} /> Analyseren…</> : <><Zap size={13} /> Analyseer op GIBIT/ARBIT</>}
      </Button>
      {result && (
        <div className="bg-gov-light border border-gov/20 rounded-xl p-3.5 text-[11px] text-gov-dark leading-relaxed fade-up">
          <strong className="block mb-2 text-gov font-bold">GIBIT/ARBIT Analyse</strong>
          {result.gibit_issues?.length
            ? result.gibit_issues.map((issue, i) => (
                <div key={i} className="flex gap-2 mb-2">
                  <span className="font-bold shrink-0" style={{ color: issue.level === 'hoog' ? '#c0392b' : '#d97706' }}>▶</span>
                  <div>
                    <span className="text-[9px] font-bold uppercase" style={{ color: issue.level === 'hoog' ? '#c0392b' : '#d97706' }}>Afwijking ({issue.level})</span>
                    <span className="text-[9px] text-gray-400 ml-2">{issue.article}</span>
                    <div>{issue.message}</div>
                  </div>
                </div>
              ))
            : <div className="text-green font-semibold">✓ Geen directe GIBIT/ARBIT afwijkingen gedetecteerd.</div>
          }
          <div className="text-[10px] text-gray-500 mt-2 pt-2 border-t border-gov/20">{result.summary}</div>
        </div>
      )}
    </AICard>
  )
}

// ── Predictive Health Score ────────────────────────────────────────
function PredictiveHealth({ vendors }) {
  const [vendorId, setVendorId] = useState('')
  const [result, setResult]     = useState(null)
  const [loading, setLoad]      = useState(false)

  const run = () => {
    const v = vendors.find(x => x.id === +vendorId)
    if (!v) return
    setLoad(true)
    setTimeout(() => {
      const score = v.health_score ?? 60
      const fake  = [score-12,score-8,score-5,score-3,score-1,score,score]
      const slope = (fake[6]-fake[0])/6
      const predicted = [1,2,3].map(i => Math.round(Math.max(0,Math.min(100,score+slope*i))))
      const trend = predicted[2]-score
      setResult({ score, predicted, trend })
      setLoad(false)
    }, 1200)
  }

  return (
    <AICard title="Predictive Health Score" sub="AI voorspelt score-daling vóór rapportage" color="#077a8a"
      desc="Analyseert MTTR-trends en KPI-historiek om dalende scores 3 periodes van te voren te signaleren.">
      <Select label="Selecteer Leverancier" value={vendorId} onChange={e => setVendorId(e.target.value)}>
        <option value="">– Kies leverancier –</option>
        {vendors.map(v => <option key={v.id} value={v.id}>{vName(v)}</option>)}
      </Select>
      <Button onClick={run} disabled={loading || !vendorId} className="self-start" style={{ background: '#077a8a' }}>
        {loading ? <><Spinner size={13} /> Analyseren…</> : <><Zap size={13} /> Voorspel Score Trend</>}
      </Button>
      {result && (
        <div className="bg-gov-light border border-gov/20 rounded-xl p-3.5 fade-up">
          <strong className="block mb-3 text-gov font-bold text-[11px]">Predictive Health Score</strong>
          <div className="grid grid-cols-4 gap-2 mb-3">
            {[{ val: result.score, label: 'Huidig' }, ...result.predicted.map((p, i) => ({ val: p, label: `P+${i+1}` }))].map((item, i) => (
              <div key={i} className="text-center">
                <div className="text-[18px] font-black font-syne" style={{ color: item.val >= 70 ? '#1a9e5c' : item.val >= 50 ? '#d97706' : '#c0392b', opacity: i === 0 ? 1 : 1 - i*0.1 }}>{item.val}</div>
                <div className="text-[9px] text-gray-400">{item.label}</div>
              </div>
            ))}
          </div>
          <div className="text-[11px]">Trend: <strong style={{ color: result.trend > 2 ? '#1a9e5c' : result.trend < -2 ? '#c0392b' : '#d97706' }}>{result.trend > 2 ? '▲ Stijgend' : result.trend < -2 ? '▼ Dalend' : '→ Stabiel'}</strong></div>
          {result.predicted[2] < 50 && result.score >= 50 && (
            <div className="mt-2 bg-red-bg border border-red/20 rounded-lg px-3 py-2 text-[10px] text-red font-semibold">⚠ Voorspelling: Score daalt onder 50 in ~3 periodes. Preventieve actie aanbevolen.</div>
          )}
        </div>
      )}
    </AICard>
  )
}

// ── Budget Indexatie ───────────────────────────────────────────────
function BudgetPredictor({ vendors }) {
  const [vendorId, setVendorId] = useState('')
  const [result, setResult]     = useState(null)
  const [loading, setLoad]      = useState(false)
  const CBS = 3.2, CAP = 2.8, APPLIED = Math.min(CBS, CAP)

  const run = () => {
    const v = vendors.find(x => x.id === +vendorId)
    if (!v) return
    setLoad(true)
    setTimeout(() => {
      const totalVal = v.contracts?.reduce((s,c) => s+(c.total_value||0),0) || 0
      const increase = totalVal * APPLIED / 100
      setResult({ totalVal, increase, newVal: totalVal + increase })
      setLoad(false)
    }, 1000)
  }

  return (
    <AICard title="Budget & Indexatie Voorspeller" sub="CBS-index + contractclausules" color="#d97706"
      desc="Berekent verwachte prijsstijgingen zodat de Contract Eigenaar dit kan opnemen in de begroting.">
      <Select label="Selecteer Leverancier" value={vendorId} onChange={e => setVendorId(e.target.value)}>
        <option value="">– Kies leverancier –</option>
        {vendors.map(v => <option key={v.id} value={v.id}>{vName(v)}</option>)}
      </Select>
      <Button onClick={run} disabled={loading || !vendorId} className="self-start" style={{ background: '#d97706' }}>
        {loading ? <><Spinner size={13} /> Berekenen…</> : <><Zap size={13} /> Bereken Indexatie 2026</>}
      </Button>
      {result && (
        <div className="bg-gov-light border border-gov/20 rounded-xl p-3.5 fade-up">
          <div className="grid grid-cols-2 gap-2.5 mb-3">
            {[{ label:'CBS Index 2025', val:`${CBS}%`, color:'#d97706' },{ label:'Contractuele Cap', val:`${CAP}%`, color:'#154273' },{ label:'Huidig 2025', val:fmtEur(result.totalVal), color:'#1a1f2e' },{ label:'Verwacht 2026', val:fmtEur(Math.round(result.newVal)), color:'#1a9e5c', bg:'#eaf7f1' }].map((item,i) => (
              <div key={i} className="rounded-lg p-2.5 border border-gray-200" style={{ background: item.bg || '#fff' }}>
                <div className="text-[9px] text-gray-400 uppercase tracking-wider mb-1">{item.label}</div>
                <div className="text-[18px] font-extrabold font-syne" style={{ color: item.color }}>{item.val}</div>
              </div>
            ))}
          </div>
          <div className="text-[10px] text-gov-dark">Stijging: <strong>{fmtEur(Math.round(result.increase))}</strong> (+{APPLIED}% toegepast op contractuele cap)</div>
        </div>
      )}
    </AICard>
  )
}

// ── Meeting Minutes ────────────────────────────────────────────────
function MeetingMinutes() {
  const [text, setText]     = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoad]  = useState(false)

  const run = () => {
    if (!text.trim()) return
    setLoad(true)
    setTimeout(() => {
      const patterns = [/we (moeten|gaan|plannen|spreken)[^.]+\./gi, /actie[^.]+\./gi]
      const actions = []
      patterns.forEach(p => { const m = text.match(p); if (m) actions.push(...m.slice(0,2)) })
      if (!actions.length) actions.push('Follow-up inplannen.', 'Samenvatting sturen naar deelnemers.')
      setResult({ summary: text.substring(0,200), actions })
      setLoad(false)
    }, 1400)
  }

  return (
    <AICard title="Meeting Minutes & Action Tracker" sub="AI luistert mee en extraheert acties" color="#6d3fc0"
      desc="Genereert gestructureerde notulen en zet actiepunten direct door naar de Actionable Playbooks.">
      <Textarea label="Vergadertranscript (plak tekst)"
        placeholder='Bijv: "John: We moeten de SLA voor P1 incidenten aanscherpen. Sarah: Akkoord, target 4u i.p.v. 8u…"'
        value={text} onChange={e => setText(e.target.value)} />
      <Button onClick={run} disabled={loading || !text.trim()} className="self-start" style={{ background: '#6d3fc0' }}>
        {loading ? <><Spinner size={13} /> Genereren…</> : <><Zap size={13} /> Genereer Notulen + Acties</>}
      </Button>
      {result && (
        <div className="bg-gov-light border border-gov/20 rounded-xl p-3.5 fade-up">
          <strong className="block mb-2 text-gov font-bold text-[11px]">AI Notulen</strong>
          <div className="text-[10px] text-gray-600 mb-3 leading-relaxed">{result.summary}{text.length > 200 ? '…' : ''}</div>
          <strong className="block mb-2 text-gov font-bold text-[11px]">Actiepunten ({result.actions.length})</strong>
          {result.actions.map((a, i) => (
            <div key={i} className="flex gap-2 text-[10px] text-gray-700 mb-1.5">
              <span className="font-bold text-gov shrink-0">{i+1}.</span>
              <span>{a.trim()}</span>
            </div>
          ))}
          <div className="text-[9px] text-gray-400 mt-2">Actiepunten doorgestuurd naar Actionable Playbooks.</div>
        </div>
      )}
    </AICard>
  )
}

export default function AIToolsView() {
  const { data: vendors = [] } = useVendors()
  return (
    <div>
      <div className="text-[11px] text-gray-400 mb-4">Mock AI – simulaties van productie-functionaliteit</div>
      <div className="grid grid-cols-2 gap-4 max-w-[900px]">
        <ClauseAnalyzer />
        <PredictiveHealth vendors={vendors} />
        <MeetingMinutes />
        <BudgetPredictor vendors={vendors} />
      </div>
    </div>
  )
}
