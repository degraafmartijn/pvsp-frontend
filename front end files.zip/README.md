# PVSP Frontend — React + Vite + Tailwind

React SPA for the **Public Vendor Success Platform** (V5.1).

## Quickstart

```bash
npm install
cp .env.example .env          # optional — defaults point to localhost:8000
npm run dev
```

Open **http://localhost:3000**

> The backend must be running on `http://localhost:8000`.  
> All `/api/*` requests are proxied by Vite to the FastAPI server.

---

## Project layout

```
src/
├── api/
│   └── client.js          axios instance + all API functions
├── hooks/
│   └── useVendors.js      React Query hooks for every endpoint
├── lib/
│   └── utils.js           VHS calc, RAG, fmtEur, daysLeft, helpers
├── components/
│   ├── ui/
│   │   └── index.jsx      Badge, Button, Card, Modal, Drawer, ScoreArc,
│   │                      MetricBar, Sparkline, Toast, FilterGroup, …
│   ├── layout/
│   │   ├── Sidebar.jsx    Navigation + persona switcher
│   │   └── Topbar.jsx     Search + + Taak button + alerts chip
│   ├── vendors/
│   │   ├── VendorCard.jsx      Vendor card with score arc + metric bars
│   │   ├── VendorDrawer.jsx    Full detail with all 4 datamodel sections
│   │   └── PlaybookModal.jsx   V5.1 playbook + AI evidence
│   └── tasks/
│       └── TaskModal.jsx       New task form
├── views/
│   ├── DashboardView.jsx   Persona-aware KPIs + vendor grid + Kraljic
│   ├── ManagerView.jsx     Team table + compliance heatmap + workload
│   ├── VendorsView.jsx     Full vendor grid with filters
│   ├── RenewalView.jsx     Funnel steps + contracts table
│   ├── RiskLogView.jsx     Risk log table with mitigate action
│   ├── TasksView.jsx       Kanban board (Open / In Uitvoering / Afgerond)
│   ├── GovernanceView.jsx  Overlegmatrix + meeting registration
│   ├── AIToolsView.jsx     4 AI tools (clause, predictive, budget, minutes)
│   ├── AlertsView.jsx      Auto-generated alerts from vendor data
│   └── AnalyticsView.jsx   Bar + donut + lifecycle + risk charts
└── App.jsx                 React Router + layout shell
```

---

## Key design decisions

- **React Query** for all server state — no Redux needed.
- **Axios proxy** through Vite dev server (`/api` → `http://localhost:8000`).
- **Tailwind** with custom design tokens matching the prototype's CSS variables.
- **No localStorage** — all state is either server-side (React Query) or ephemeral React state.
- The `Drawer` and `Modal` components handle keyboard (`Escape`) and backdrop click dismissal.

---

## Tailwind custom tokens

| Token | Value |
|---|---|
| `gov` | #154273 (Rijksoverheid blauw) |
| `gold` | #c9a227 |
| `green` | #1a9e5c |
| `amber` | #d97706 |
| `red` | #c0392b |
| `purple` | #6d3fc0 |
| `teal` | #0e7c87 |

---

## Production build

```bash
npm run build          # outputs to dist/
npm run preview        # preview production build locally
```

Set `VITE_API_URL` in `.env` for a non-localhost backend:

```
VITE_API_URL=https://api.pvsp.overheid.nl
```

Then update `src/api/client.js` baseURL to `import.meta.env.VITE_API_URL`.
