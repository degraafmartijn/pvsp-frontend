import { AlertTriangle, Play } from 'lucide-react'
import { ScoreArc, MetricBar, Sparkline, Badge } from '@/components/ui'
import { calcScore, rag, RAG_COLOR, fmtEur, daysLeft, predictScore, vName, vEnd, clsx } from '@/lib/utils'

const KM = {
  strategic:  { label: 'Strategisch', color: '#154273', bg: '#e8f0fa' },
  leverage:   { label: 'Hefboom',     color: '#077a8a', bg: '#e0f5f7' },
  bottleneck: { label: 'Knelpunt',    color: '#c0392b', bg: '#fdecea' },
  routine:    { label: 'Routine',     color: '#5c6575', bg: '#f5f5f5' },
}
const LC = {
  onboarding: { label: 'Onboarding', color: '#6d3fc0', bg: '#f0eafb' },
  active:     { label: 'Actief',     color: '#1a9e5c', bg: '#eaf7f1' },
  renewal:    { label: 'Renewal',    color: '#d97706', bg: '#fef3e0' },
  exit:       { label: 'Exit',       color: '#c0392b', bg: '#fdecea' },
}

export default function VendorCard({ vendor, onOpen, onPlaybook }) {
  // vendor may come from the summary list (no nested h) OR full record
  const h = vendor.latest_health ?? {
    c: vendor.health_compliance  ?? 50,
    p: vendor.health_performance ?? 50,
    a: vendor.health_adoption    ?? 50,
    s: vendor.health_sentiment   ?? 50,
  }
  const score = vendor.health_score ?? calcScore(h)
  const r = rag(score)
  const km = KM[vendor.kraljic_category] || KM.routine
  const lc = LC[vendor.lifecycle_stage]  || LC.active
  const endDate = vEnd(vendor)
  const days = endDate ? daysLeft(endDate) : null

  // history from nested health_metrics if available
  const history   = (vendor.health_metrics || []).map(m => calcScore({ c: m.compliance, p: m.performance, a: m.adoption, s: m.sentiment })).slice(0, 7).reverse()
  const histFull  = history.length >= 3 ? history : [50, 55, 60, 65, score, score, score].slice(-7)
  const predicted = predictScore(histFull)

  const needsPlaybook = score < 50

  return (
    <div
      className="bg-white rounded-xl border border-gray-200 shadow-card hover:shadow-card-md hover:-translate-y-0.5 transition-all duration-200 flex flex-col gap-2.5 cursor-pointer fade-up overflow-hidden"
      style={{ borderLeft: `4px solid ${km.color}` }}
      onClick={() => onOpen?.(vendor.id)}
    >
      <div className="p-3.5 flex flex-col gap-2.5">
        {/* Header */}
        <div className="flex justify-between items-start gap-2">
          <div className="min-w-0">
            <div className="text-[12px] font-bold text-gray-900 leading-snug truncate">{vName(vendor)}</div>
            <div className="text-[9px] text-gray-400 mt-0.5">{vendor.account_manager} · {vendor.domain || '–'}</div>
          </div>
          <ScoreArc score={score} />
        </div>

        {/* Badges */}
        <div className="flex items-center gap-1 flex-wrap">
          <Badge color={km.color} bg={km.bg}>{km.label}</Badge>
          <Badge color={lc.color} bg={lc.bg} className="text-[8px]">{lc.label}</Badge>
        </div>

        {/* Metric bars */}
        <div className="flex flex-col gap-1">
          <MetricBar label="Compliance"  value={h.c ?? 50} weight="35%" />
          <MetricBar label="Performance" value={h.p ?? 50} weight="35%" />
          <MetricBar label="Adoptie"     value={h.a ?? 50} weight="20%" />
          <MetricBar label="Sentiment"   value={h.s ?? 50} weight="10%" />
        </div>

        {/* Sparkline */}
        <div className="flex items-center justify-between">
          <Sparkline history={histFull} predicted={predicted} />
          <span className="text-[9px] text-gray-400 ml-1.5">trend</span>
        </div>

        {/* Footer */}
        <div className="flex justify-between items-center text-[10px] text-gray-400 pt-1.5 border-t border-gray-100">
          <span>{vendor.contracts?.length ?? vendor.contract_count ?? 0} contract{(vendor.contracts?.length ?? 0) !== 1 ? 's' : ''}</span>
          <span className="font-mono">{fmtEur(vendor.contracts?.reduce((s, c) => s + (c.total_value || 0), 0) || 0)}</span>
          {days !== null && (
            <span className={days <= 90 ? 'text-red font-semibold' : ''}>
              {days > 0 ? `${days}d` : 'Verlopen'}
            </span>
          )}
        </div>
      </div>

      {/* Playbook trigger */}
      {needsPlaybook && (
        <button
          onClick={(e) => { e.stopPropagation(); onPlaybook?.(vendor) }}
          className="w-full flex items-center justify-center gap-1.5 bg-red text-white text-[10px] font-bold py-2 px-3 hover:bg-red-700 transition-colors pulse-red cursor-pointer border-0"
        >
          <AlertTriangle size={10} />
          Score Kritiek – Start Playbook
          <Play size={9} fill="white" />
        </button>
      )}
    </div>
  )
}
