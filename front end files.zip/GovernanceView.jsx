// ── GovernanceView.jsx ─────────────────────────────────────────────
import { useState } from 'react'
import { useVendors } from '@/hooks/useVendors'
import { useCreateMeeting } from '@/hooks/useVendors'
import { Card, SectionHeader, Modal, Select, Textarea, Button, useToast } from '@/components/ui'
import { vName } from '@/lib/utils'

const LEVELS = [
  { key: 'operationeel', label: 'Operationeel',  freq: 'Wekelijks / Maandelijks', color: '#077a8a',
    participants: 'Contract Manager, Supplier Support', focus: 'Incidenten, SLA-tickets',
    ai: 'Vat wekelijkse ticket-data samen tot incidentrapportage',
    agenda: 'Incident log · SLA rapportage · Capaciteitsmonitor' },
  { key: 'tactisch', label: 'Tactisch – QBR', freq: 'Kwartaal', color: '#154273',
    participants: 'Contract Manager, Product Owner, Account Manager', focus: 'Roadmap, VHS trends, Compliance',
    ai: 'Genereert automatisch QBR-agenda op basis van KPI-data',
    agenda: 'VHS review · Roadmap update · Compliance check' },
  { key: 'strategisch', label: 'Strategisch', freq: 'Jaarlijks', color: '#6d3fc0',
    participants: 'Contract Eigenaar, Leverancier Directie, Contract Manager', focus: 'Partnership, Innovatie, Kraljic',
    ai: 'Benchmarking t.o.v. markt + Kraljic herpositioneringsadvies',
    agenda: 'Innovatie-agenda · Benchmarking · Contract herziening' },
]

export function GovernanceView() {
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState({ type: 'operationeel', vendorId: '', transcript: '' })
  const toast = useToast()
  const { data: vendors = [] } = useVendors()
  const createMeeting = useCreateMeeting()

  const save = async () => {
    if (!form.vendorId) return
    await createMeeting.mutateAsync({
      vendorId: +form.vendorId,
      data: {
        meeting_type: form.type,
        meeting_date: new Date().toISOString().split('T')[0],
        transcript: form.transcript,
        summary: form.transcript ? `AI Notulen: ${form.transcript.substring(0, 100)}…` : 'Geregistreerd.',
        action_points: JSON.stringify(form.transcript ? ['Actiepunt extraheren', 'Follow-up inplannen'] : ['Follow-up inplannen']),
      }
    })
    setModalOpen(false)
    toast('✓ Vergadering opgeslagen en AI notulen gegenereerd.')
  }

  return (
    <div className="max-w-[980px]">
      <div className="grid grid-cols-3 gap-3.5 mb-6">
        {LEVELS.map((l, i) => (
          <Card key={l.key} className="overflow-hidden fade-up" style={{ animationDelay: `${i*0.08}s` }}>
            <div className="px-4 py-3.5" style={{ background: l.color }}>
              <div className="text-white font-syne text-[13px] font-bold">{l.label}</div>
              <div className="text-white/70 text-[10px] mt-0.5">{l.freq}</div>
            </div>
            <div className="p-4 flex flex-col gap-3">
              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1">Deelnemers</div>
                <div className="text-[11px] text-gray-900">{l.participants}</div>
              </div>
              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1">Focus</div>
                <div className="text-[11px] text-gray-900">{l.focus}</div>
              </div>
              <div className="bg-gold-bg border border-gold/20 rounded-lg p-2.5">
                <div className="text-[9px] font-bold text-gold uppercase tracking-wider mb-1">⚡ AI Ondersteuning</div>
                <div className="text-[10px] text-yellow-800">{l.ai}</div>
              </div>
              <div>
                <div className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-1">Standaard Agenda</div>
                <div className="text-[10px] text-gray-600">{l.agenda}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <SectionHeader title="Overleg Logboek">
        <Button size="sm" onClick={() => setModalOpen(true)}>+ Vergadering Toevoegen</Button>
      </SectionHeader>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Vergadering Registreren" headerColor="#154273" width={480}>
        <Select label="Vergadertype" value={form.type} onChange={e => setForm(f => ({...f,type:e.target.value}))}>
          <option value="operationeel">Operationeel (wekelijks/maandelijks)</option>
          <option value="tactisch">Tactisch – QBR (kwartaal)</option>
          <option value="strategisch">Strategisch (jaarlijks)</option>
        </Select>
        <Select label="Leverancier" value={form.vendorId} onChange={e => setForm(f => ({...f,vendorId:e.target.value}))}>
          <option value="">– Kies leverancier –</option>
          {vendors.map(v => <option key={v.id} value={v.id}>{vName(v)}</option>)}
        </Select>
        <Textarea label="Transcript / Notities" placeholder="Plak vergadertranscript…" value={form.transcript}
          onChange={e => setForm(f => ({...f,transcript:e.target.value}))} />
        <div className="flex gap-2">
          <Button variant="primary" className="flex-1" onClick={save}>Opslaan + AI Notulen</Button>
          <Button variant="secondary" className="flex-1" onClick={() => setModalOpen(false)}>Annuleren</Button>
        </div>
      </Modal>
    </div>
  )
}

export default GovernanceView
