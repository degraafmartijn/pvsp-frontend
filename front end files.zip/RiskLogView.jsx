import { useState } from 'react'
import { useRisks, useUpdateRisk } from '@/hooks/useVendors'
import { SectionHeader, FilterGroup, Badge, useToast } from '@/components/ui'

export default function RiskLogView() {
  const [levelFilter, setLevelFilter] = useState('all')
  const toast = useToast()
  const params = levelFilter !== 'all' ? { level: levelFilter } : {}
  const { data: risks = [], isLoading } = useRisks(params)
  const updateRisk = useUpdateRisk()

  const mitigate = async (risk) => {
    await updateRisk.mutateAsync({ id: risk.id, data: { status: 'in_behandeling' } })
    toast(`Risico "${risk.signal}" in behandeling genomen.`)
  }

  const lvlColor  = { high: '#c0392b', medium: '#d97706', low: '#1a9e5c' }
  const lvlBg     = { high: '#fdecea', medium: '#fef3e0', low: '#eaf7f1' }
  const stColor   = { open: '#c0392b', in_behandeling: '#d97706', afgehandeld: '#1a9e5c' }
  const stBg      = { open: '#fdecea', in_behandeling: '#fef3e0', afgehandeld: '#eaf7f1' }
  const stLabel   = { open: 'Open',   in_behandeling: 'In behandeling', afgehandeld: 'Afgehandeld' }

  return (
    <div className="max-w-[920px]">
      <SectionHeader title="AI Risk Log">
        <FilterGroup
          options={[{value:'all',label:'Alle'},{value:'high',label:'Hoog'},{value:'medium',label:'Medium'},{value:'low',label:'Laag'}]}
          active={levelFilter}
          onChange={setLevelFilter}
        />
      </SectionHeader>

      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-card">
        <table className="w-full border-collapse text-[11px]">
          <thead>
            <tr className="bg-gov-light">
              {['Leverancier','Risico Signaal','Bron','Clausule/KPI','Niveau','Datum','Status'].map(h => (
                <th key={h} className="text-left px-3.5 py-2.5 text-gov font-bold text-[10px] uppercase tracking-wider border-b border-gray-200">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {risks.map(r => (
              <tr key={r.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                <td className="px-3.5 py-2.5 font-semibold">{r.vendor}</td>
                <td className="px-3.5 py-2.5 text-gray-700">{r.signal}</td>
                <td className="px-3.5 py-2.5 text-gray-500">{r.source}</td>
                <td className="px-3.5 py-2.5 font-mono text-[10px]">{r.clause}</td>
                <td className="px-3.5 py-2.5">
                  <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full" style={{ background: lvlBg[r.level], color: lvlColor[r.level] }}>{r.level.toUpperCase()}</span>
                </td>
                <td className="px-3.5 py-2.5 text-gray-400">{r.detected_at}</td>
                <td className="px-3.5 py-2.5">
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background: stBg[r.status], color: stColor[r.status] }}>{stLabel[r.status]}</span>
                  {r.status === 'open' && (
                    <button
                      onClick={() => mitigate(r)}
                      className="ml-2 text-[9px] font-semibold px-2 py-0.5 border border-gray-200 rounded-md hover:border-gov hover:text-gov transition-colors cursor-pointer bg-transparent"
                    >
                      Mitigeer
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {!isLoading && risks.length === 0 && (
              <tr><td colSpan={7} className="px-4 py-12 text-center text-gray-400">Geen risico's gevonden.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}
