import { useState } from 'react'
import { Plus, Clock, CheckCircle } from 'lucide-react'
import { useTasks, useUpdateTask, useDeleteTask } from '@/hooks/useVendors'
import { TaskModal } from '@/components/tasks/TaskModal'
import { SectionHeader, FilterGroup, Button, useToast, Card } from '@/components/ui'

const PRI_COLOR = { hoog: '#c0392b', medium: '#d97706', laag: '#9aa3b0' }
const CAT_BG    = { Compliance: '#f0eafb', Contract: '#e8f0fa', Renewal: '#fef3e0', Governance: '#e0f5f7', Budget: '#fef8e7', 'VHS Kritiek': '#fdecea', Overig: '#f5f5f5' }
const CAT_COL   = { Compliance: '#6d3fc0', Contract: '#154273', Renewal: '#d97706', Governance: '#077a8a', Budget: '#c9a227', 'VHS Kritiek': '#c0392b', Overig: '#5c6575' }

function TaskCard({ task, onToggle }) {
  const done = task.status === 'done'
  return (
    <div className={`bg-white border border-gray-200 rounded-[9px] px-4 py-3 mb-2 shadow-card hover:shadow-card-md hover:-translate-y-0.5 transition-all duration-150 relative overflow-hidden fade-up ${done ? 'opacity-55' : ''}`}>
      <div className="absolute left-0 top-0 bottom-0 w-1 rounded-l-[9px]" style={{ background: PRI_COLOR[task.priority] || '#9aa3b0' }} />
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div className={`text-[11px] font-bold text-gray-900 leading-snug flex-1 ${done ? 'line-through text-gray-400' : ''}`}>{task.title}</div>
        <button
          onClick={() => onToggle(task)}
          className="w-5 h-5 rounded-full border-[1.5px] flex items-center justify-center shrink-0 cursor-pointer transition-all bg-transparent mt-0.5"
          style={{ borderColor: done ? '#1a9e5c' : '#d1d5db', color: done ? '#1a9e5c' : '#9aa3b0' }}
        >
          {done
            ? <CheckCircle size={12} fill="#1a9e5c" stroke="none" />
            : <div className="w-2 h-2 rounded-full bg-gray-200" />
          }
        </button>
      </div>
      {task.vendor && <div className="text-[10px] font-semibold text-gov mb-1.5">{task.vendor?.trade_name || task.vendor?.legal_name}</div>}
      <div className="flex flex-wrap gap-1.5 mb-2">
        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: CAT_BG[task.category] || '#f5f5f5', color: CAT_COL[task.category] || '#5c6575' }}>{task.category}</span>
        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">{task.source}</span>
      </div>
      <div className="flex items-center gap-2 text-[10px] text-gray-400">
        <Clock size={9} />
        <span>{task.due_date || '–'}</span>
        {task.assignee && <><span>·</span><span className="text-gov font-semibold">{task.assignee}</span></>}
        <span className="ml-auto text-[9px] font-bold capitalize" style={{ color: PRI_COLOR[task.priority] }}>{task.priority}</span>
      </div>
    </div>
  )
}

export default function TasksView({ onNewTask }) {
  const [taskFilter, setTaskFilter] = useState('all')
  const [modalOpen, setModalOpen]   = useState(false)
  const [defaultStatus, setDefault] = useState('open')
  const toast = useToast()
  const params = taskFilter !== 'all' ? { status: taskFilter } : {}
  const { data: allTasks = [] } = useTasks({})
  const { data: tasks = [] }    = useTasks(params)
  const updateTask = useUpdateTask()

  const toggle = async (task) => {
    const next = task.status === 'done' ? 'open' : task.status === 'open' ? 'inprogress' : 'done'
    await updateTask.mutateAsync({ id: task.id, data: { status: next } })
    toast(`Taak → ${next}`)
  }

  const open       = tasks.filter(t => t.status === 'open')
  const inprogress = tasks.filter(t => t.status === 'inprogress')
  const done       = tasks.filter(t => t.status === 'done')
  const openCount  = allTasks.filter(t => t.status === 'open').length

  const openModal = (status = 'open') => { setDefault(status); setModalOpen(true) }

  return (
    <div className="max-w-[1060px]">
      <SectionHeader title="Taken & Playbooks" sub={`${tasks.length} taken · ${openCount} open`}>
        <div className="flex items-center gap-2">
          <FilterGroup
            options={[{value:'all',label:'Alle'},{value:'open',label:'Open'},{value:'inprogress',label:'In Uitvoering'},{value:'done',label:'Afgerond'}]}
            active={taskFilter}
            onChange={setTaskFilter}
          />
          <Button size="sm" onClick={() => openModal()}>
            <Plus size={11} /> Nieuwe Taak
          </Button>
        </div>
      </SectionHeader>

      <div className="grid grid-cols-3 gap-3.5">
        {/* Open */}
        <div className="bg-gray-100 rounded-xl p-3">
          <div className="flex items-center justify-between mb-2.5">
            <div className="text-[11px] font-bold text-gray-900 flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-red" />
              Open
              <span className="bg-white border border-gray-200 text-gray-500 rounded-full text-[9px] font-bold px-1.5 py-0.5">{open.length}</span>
            </div>
          </div>
          {open.map(t => <TaskCard key={t.id} task={t} onToggle={toggle} />)}
          <button
            onClick={() => openModal('open')}
            className="w-full py-2 rounded-lg border-[1.5px] border-dashed border-gray-200 text-[11px] text-gray-400 hover:border-gov hover:text-gov hover:bg-gov-light flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-transparent"
          >
            <Plus size={11} /> Taak toevoegen
          </button>
        </div>

        {/* In Uitvoering */}
        <div className="bg-gray-100 rounded-xl p-3">
          <div className="flex items-center justify-between mb-2.5">
            <div className="text-[11px] font-bold text-gray-900 flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-amber" />
              In Uitvoering
              <span className="bg-white border border-gray-200 text-gray-500 rounded-full text-[9px] font-bold px-1.5 py-0.5">{inprogress.length}</span>
            </div>
          </div>
          {inprogress.map(t => <TaskCard key={t.id} task={t} onToggle={toggle} />)}
          <button
            onClick={() => openModal('inprogress')}
            className="w-full py-2 rounded-lg border-[1.5px] border-dashed border-gray-200 text-[11px] text-gray-400 hover:border-gov hover:text-gov hover:bg-gov-light flex items-center justify-center gap-1.5 transition-all cursor-pointer bg-transparent"
          >
            <Plus size={11} /> Taak toevoegen
          </button>
        </div>

        {/* Afgerond */}
        <div className="bg-gray-100 rounded-xl p-3">
          <div className="flex items-center justify-between mb-2.5">
            <div className="text-[11px] font-bold text-gray-900 flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-green" />
              Afgerond
              <span className="bg-white border border-gray-200 text-gray-500 rounded-full text-[9px] font-bold px-1.5 py-0.5">{done.length}</span>
            </div>
          </div>
          {done.map(t => <TaskCard key={t.id} task={t} onToggle={toggle} />)}
        </div>
      </div>

      <TaskModal open={modalOpen} onClose={() => setModalOpen(false)} defaultStatus={defaultStatus} />
    </div>
  )
}
