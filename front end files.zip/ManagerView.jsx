import { useVendors, useRisks, useTasks, useExpiringContracts } from '@/hooks/useVendors'
import { Card, SectionHeader, Badge } from '@/components/ui'
import { rag, RAG_COLOR, fmtEur, vName, daysLeft, complianceScore } from '@/lib/utils'
import { useNavigate } from 'react-router-dom'

const TEAM = [
  { name:'A. Smit',    initials:'AS', color:'#154273', vendorIds:[1,4] },
  { name:'C. Bakker',  initials:'CB', color:'#c0392b', vendorIds:[3]   },
  { name:'B. de Jong', initials:'BJ', color:'#6d3fc0', vendorIds:[2,5,6] },
]
const KM = { strategic:{color:'#154273',bg:'#e8f0fa',label:'Strategisch'}, leverage:{color:'#077a8a',bg:'#e0f5f7',label:'Hefboom'}, bottleneck:{color:'#c0392b',bg:'#fdecea',label:'Knelpunt'}, routine:{color:'#5c6575',bg:'#f5f5f5',label:'Routine'} }

function MgrKpi({ label, value, color, sub }) {
  return (
    <Card className="p-3.5">
      <div className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider mb-1.5">{label}</div>
      <div className="text-[26px] font-extrabold font-syne leading-none" style={{ color }}>{value}</div>
      {sub && <div className="text-[10px] text-gray-400 mt-1">{sub}</div>}
    </Card>
  )
}

export default function ManagerView() {
  const { data: vendors = [] }   = useVendors()
  const { data: openRisks = [] } = useRisks({ status: 'open' })
  const { data: openTasks = [] } = useTasks({ status: 'open' })
  const { data: expiring = [] }  = useExpiringContracts(365)
  const navigate = useNavigate()

  const avgVhs = vendors.length
    ? Math.round(vendors.reduce((a, v) => a + (v.health_score ?? 50), 0) / vendors.length)
    : 0
  const critCount     = vendors.filter(v => (v.health_score ?? 50) < 50).length
  const compIssueCount = vendors.filter(v => complianceScore(v.compliance) < 80).length

  return (
    <div>
      {/* Header banner */}
      <div className="flex items-center gap-3.5 rounded-xl px-5 py-4 mb-5 text-white"
        style={{ background: 'linear-gradient(135deg,#154273 0%,#1c5491 100%)' }}>
        <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center shrink-0">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div>
          <div className="font-syne text-[16px] font-extrabold">Manager Dashboard</div>
          <div className="text-white/60 text-[11px] mt-0.5">Teamoverzicht · Openstaande taken · Renewals · Compliance · Health Scores</div>
        </div>
        <div className="ml-auto text-[10px] text-white/50">Ministerie BZK · Contractbeheer Team</div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-3 mb-5">
        <MgrKpi label="Gem. VHS Team"      value={avgVhs}          color="#1a9e5c" sub="Alle leveranciers" />
        <MgrKpi label="Kritieke Vendors"   value={critCount}       color="#c0392b" sub="VHS < 50" />
        <MgrKpi label="Open Risico's"      value={openRisks.length} color="#d97706" sub="Onopgelost" />
        <MgrKpi label="Compliance Issues"  value={compIssueCount}  color="#6d3fc0" sub="Score < 80%" />
      </div>

      <div className="grid grid-cols-[1fr_300px] gap-5 items-start">
        {/* Main left column */}
        <div className="flex flex-col gap-5">
          {/* Team table */}
          <div>
            <SectionHeader title="Team Overzicht" sub="Contract Managers & hun portfolio" />
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-card">
              <table className="w-full border-collapse text-[11px]">
                <thead>
                  <tr className="bg-gov-light">
                    {['Medewerker','Leveranciers','Open Taken','Renewals','Gem. VHS','Compliance','Status'].map(h => (
                      <th key={h} className="text-left px-3.5 py-2.5 text-gov font-bold text-[10px] uppercase tracking-wider border-b border-gray-200">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {TEAM.map(tm => {
                    const tmVendors = vendors.filter(v => tm.vendorIds.includes(v.id))
                    const tmScores  = tmVendors.map(v => v.health_score ?? 50)
                    const tmAvg     = tmScores.length ? Math.round(tmScores.reduce((a,b)=>a+b,0)/tmScores.length) : 0
                    const r         = rag(tmAvg)
                    const tmRenewals = expiring.filter(c => tmVendors.some(v => v.id === c.vendor_id)).length
                    const tmCompIss = tmVendors.filter(v => complianceScore(v.compliance) < 80).length
                    const statusLabel = tmScores.some(s=>s<50)?'Actie vereist':tmScores.some(s=>s<70)?'Aandacht':'Goed'
                    const statusColor = tmScores.some(s=>s<50)?'#c0392b':tmScores.some(s=>s<70)?'#d97706':'#1a9e5c'

                    return (
                      <tr key={tm.name} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                        <td className="px-3.5 py-2.5">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full flex items-center justify-center text-white text-[9px] font-black shrink-0" style={{ background: tm.color }}>{tm.initials}</div>
                            <div>
                              <div className="font-semibold">{tm.name}</div>
                              <div className="text-[9px] text-gray-400">Contract Manager</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-3.5 py-2.5">
                          <div className="flex flex-wrap gap-1">
                            {tmVendors.map(v => {
                              const km = KM[v.kraljic_category]
                              return <span key={v.id} className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full" style={{ background: km?.bg, color: km?.color }}>{vName(v).split(' ')[0]}</span>
                            })}
                          </div>
                        </td>
                        <td className="px-3.5 py-2.5 font-semibold">{openTasks.filter(t => t.assignee === tm.name).length}</td>
                        <td className="px-3.5 py-2.5">
                          {tmRenewals > 0
                            ? <Badge color="#d97706" bg="#fef3e0">{tmRenewals} renewal{tmRenewals > 1 ? 's' : ''}</Badge>
                            : <span className="text-gray-400">–</span>
                          }
                        </td>
                        <td className="px-3.5 py-2.5">
                          <div className="flex items-center gap-2">
                            <div className="w-14 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                              <div className="h-full rounded-full" style={{ width:`${tmAvg}%`, background: RAG_COLOR[r] }} />
                            </div>
                            <span className="font-mono font-bold" style={{ color: RAG_COLOR[r] }}>{tmAvg}</span>
                          </div>
                        </td>
                        <td className="px-3.5 py-2.5">
                          {tmCompIss > 0
                            ? <Badge color="#6d3fc0" bg="#f0eafb">{tmCompIss} issue{tmCompIss>1?'s':''}</Badge>
                            : <span className="text-green font-semibold text-[10px]">✓ OK</span>
                          }
                        </td>
                        <td className="px-3.5 py-2.5">
                          <span className="text-[9px] font-bold px-2 py-0.5 rounded-full" style={{ background: statusColor+'18', color: statusColor }}>{statusLabel}</span>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Compliance heatmap */}
          <div>
            <SectionHeader title="Compliance Heatmap" sub="Score per leverancier (klik voor detail)" />
            <div className="grid grid-cols-3 gap-2">
              {vendors.map(v => {
                const cs = complianceScore(v.compliance) ?? 0
                const r  = rag(cs)
                return (
                  <div key={v.id}
                    className="rounded-xl p-2.5 text-center cursor-pointer hover:scale-[1.03] transition-transform border"
                    style={{ background: RAG_COLOR[r]+'18', borderColor: RAG_COLOR[r]+'44' }}
                    onClick={() => navigate('/vendors')}
                    title={`${vName(v)} — Compliance: ${cs}%`}
                  >
                    <div className="text-[9px] font-semibold overflow-hidden text-ellipsis whitespace-nowrap" style={{ color: RAG_COLOR[r] }}>{vName(v).split(' ')[0]}</div>
                    <div className="text-[15px] font-extrabold font-syne" style={{ color: RAG_COLOR[r] }}>{cs}%</div>
                    <div className="text-[8px] mt-0.5" style={{ color: RAG_COLOR[r] }}>
                      {v.compliance?.nis2_compliant ? '✓ NIS2' : '✗ NIS2'} · {v.compliance?.iso_27001_certified ? '✓ ISO' : '✗ ISO'}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Open renewals */}
          <div>
            <SectionHeader title="Open Renewals" sub="Contracten in het renewal-traject" />
            <div className="flex flex-col gap-2">
              {expiring.slice(0,6).map(c => {
                const days = daysLeft(c.end_date)
                const stageColor = days <= 90 ? '#c0392b' : days <= 180 ? '#d97706' : '#077a8a'
                const stageLabel = days <= 90 ? 'T-3' : days <= 180 ? 'T-6' : days <= 270 ? 'T-9' : 'T-12'
                return (
                  <div key={c.id} className="flex items-center gap-3 bg-gray-50 rounded-xl px-3 py-2.5 text-[10px] border border-gray-100">
                    <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: stageColor }} />
                    <div className="font-semibold flex-1 overflow-hidden text-ellipsis whitespace-nowrap">{c.contract_name}</div>
                    <span className="text-[9px] font-bold px-2 py-0.5 rounded-full shrink-0" style={{ background: stageColor+'18', color: stageColor }}>{stageLabel}</span>
                    <span className="shrink-0" style={{ color: days <= 90 ? '#c0392b' : '#9aa3b0' }}>{days > 0 ? `${days}d` : 'Verlopen'}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="flex flex-col gap-3">
          {/* Open risks */}
          <Card className="p-3.5">
            <div className="text-[12px] font-bold text-gray-900 mb-2 flex items-center justify-between">
              Open Risico's
              <span className="text-[9px] bg-red-bg text-red px-2 py-0.5 rounded-full font-bold">{openRisks.length} open</span>
            </div>
            {openRisks.slice(0,5).map(r => (
              <div key={r.id} className="flex items-start gap-2 py-1.5 border-b border-gray-100 text-[10px] last:border-0">
                <div className="w-2 h-2 rounded-full shrink-0 mt-1" style={{ background: r.level==='high'?'#c0392b':r.level==='medium'?'#d97706':'#1a9e5c' }} />
                <div>
                  <div className="font-semibold text-gray-900">{r.vendor}</div>
                  <div className="text-gray-600">{r.signal}</div>
                  <div className="text-[9px] text-gray-400">{r.source} · {r.detected_at}</div>
                </div>
              </div>
            ))}
          </Card>

          {/* Task preview */}
          <Card className="p-3.5">
            <div className="text-[12px] font-bold text-gray-900 mb-2 flex items-center justify-between">
              Openstaande Taken
              <button onClick={() => navigate('/tasks')} className="text-[9px] text-gov bg-gov-light px-2 py-0.5 rounded border-0 cursor-pointer font-bold hover:bg-gov hover:text-white transition-colors">Alle taken →</button>
            </div>
            {openTasks.slice(0,4).map(t => (
              <div key={t.id} className="py-1.5 border-b border-gray-100 text-[10px] last:border-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <div className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: t.priority==='hoog'?'#c0392b':t.priority==='medium'?'#d97706':'#9aa3b0' }} />
                  <span className="font-semibold text-gray-900 flex-1">{t.title?.substring(0,40)}</span>
                </div>
                <div className="text-[9px] text-gray-400 pl-3">{t.vendor?.trade_name || '–'} · {t.assignee || 'Niet toegewezen'}</div>
              </div>
            ))}
          </Card>

          {/* Workload */}
          <Card className="p-3.5">
            <div className="text-[12px] font-bold text-gray-900 mb-3">Team Werkdruk</div>
            {TEAM.map(tm => {
              const count = openTasks.filter(t => t.assignee === tm.name).length
              const maxLoad = 8
              const pct = Math.round((count / maxLoad) * 100)
              const color = count >= 5 ? '#c0392b' : count >= 3 ? '#d97706' : '#1a9e5c'
              return (
                <div key={tm.name} className="mb-3 last:mb-0">
                  <div className="flex justify-between text-[10px] mb-1">
                    <div className="flex items-center gap-1.5">
                      <div className="w-4 h-4 rounded-full flex items-center justify-center text-white text-[8px] font-bold" style={{ background: tm.color }}>{tm.initials}</div>
                      <span className="font-semibold">{tm.name}</span>
                    </div>
                    <span className="font-bold" style={{ color }}>{count} taken</span>
                  </div>
                  <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${Math.min(pct,100)}%`, background: color }} />
                  </div>
                </div>
              )
            })}
          </Card>
        </div>
      </div>
    </div>
  )
}
