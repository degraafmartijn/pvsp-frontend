import { useState } from 'react'
import { Building2, TrendingUp, AlertTriangle, Shield, BarChart2 } from 'lucide-react'
import { useVendors, useSummary } from '@/hooks/useVendors'
import VendorCard     from '@/components/vendors/VendorCard'
import VendorDrawer   from '@/components/vendors/VendorDrawer'
import PlaybookModal  from '@/components/vendors/PlaybookModal'
import { useToast, Card, SectionHeader, FilterGroup, LoadingGrid, Empty } from '@/components/ui'
import { fmtEur, rag, RAG_COLOR, calcScore, vName, clsx } from '@/lib/utils'

const KM = {
  strategic:  { label: 'Strategisch', color: '#154273', bg: '#e8f0fa' },
  leverage:   { label: 'Hefboom',     color: '#077a8a', bg: '#e0f5f7' },
  bottleneck: { label: 'Knelpunt',    color: '#c0392b', bg: '#fdecea' },
  routine:    { label: 'Routine',     color: '#5c6575', bg: '#f5f5f5' },
}
const PERSONAS = {
  cm: { name: 'Annet – Contract Manager',   role: 'Action Center',        focus: 'Compliance, SLA\'s, Deadlines', color: '#154273', initials: 'CM' },
  ce: { name: 'Bas – Contract Eigenaar',    role: 'Strategische Horizon', focus: 'Financieel risico, Portfolio',  color: '#6d3fc0', initials: 'CE' },
  po: { name: 'Mark – Product Owner',       role: 'Value Tracker',        focus: 'Adoptie, Gebruikers',           color: '#077a8a', initials: 'PO' },
}

function KpiCard({ label, value, Icon, color, bg, delay = 0 }) {
  return (
    <Card className="p-3.5 flex items-center gap-3 fade-up" style={{ animationDelay: `${delay}s` }}>
      <div className="w-9 h-9 rounded-[9px] flex items-center justify-center shrink-0" style={{ background: bg }}>
        <Icon size={16} style={{ color }} />
      </div>
      <div>
        <div className="text-[22px] font-extrabold font-syne leading-none" style={{ color: value === 0 ? color : undefined }}>{value}</div>
        <div className="text-[10px] text-gray-500 mt-0.5">{label}</div>
      </div>
    </Card>
  )
}

function KraljicMatrix({ vendors }) {
  const bycat = {}
  vendors.forEach(v => {
    const s = v.health_score ?? 50
    ;(bycat[v.kraljic_category] = bycat[v.kraljic_category] || []).push({ name: vName(v).split(' ')[0], score: s, r: rag(s) })
  })

  return (
    <div className="grid grid-cols-2 gap-1.5 mt-1">
      {['strategic','bottleneck','leverage','routine'].map(cat => {
        const km = KM[cat]
        const items = bycat[cat] || []
        return (
          <div key={cat} className="rounded-lg p-2.5 min-h-[80px]" style={{ background: km.bg }}>
            <div className="text-[8px] font-black uppercase tracking-widest mb-1.5" style={{ color: km.color }}>{km.label}</div>
            {items.map(it => (
              <div key={it.name} className="flex justify-between text-[9px] mb-0.5">
                <span style={{ color: km.color, fontWeight: 500 }}>{it.name}</span>
                <span className="font-mono font-bold" style={{ color: RAG_COLOR[it.r] }}>{it.score}</span>
              </div>
            ))}
            {!items.length && <span className="text-[9px] text-gray-400 italic">–</span>}
          </div>
        )
      })}
    </div>
  )
}

export default function DashboardView({ persona, search }) {
  const [ragFilter,       setRagFilter]       = useState('all')
  const [selectedVendor,  setSelectedVendor]  = useState(null)
  const [playbookVendor,  setPlaybookVendor]  = useState(null)
  const toast = useToast()

  const { data: summary } = useSummary()
  const { data: vendors = [], isLoading } = useVendors()

  const filtered = vendors.filter(v => {
    const r = rag(v.health_score ?? 50)
    const matchRag = ragFilter === 'all' || r === ragFilter
    const matchSearch = vName(v).toLowerCase().includes(search.toLowerCase())
    return matchRag && matchSearch
  })

  const pa = PERSONAS[persona]
  const avg = summary?.avg_vhs ?? 0
  const crit = summary?.critical_count ?? 0
  const openRisks = summary?.open_risks ?? 0
  const totalVal = summary?.total_contract_value ?? 0

  const kpis = persona === 'ce'
    ? [
        { label: 'Totale Portfoliowaarde', value: fmtEur(totalVal), Icon: BarChart2, color: '#c9a227', bg: 'rgba(201,162,39,0.12)' },
        { label: 'Gem. VHS Portefeuille',  value: avg,              Icon: TrendingUp, color: '#1a9e5c', bg: 'rgba(26,158,92,0.1)' },
        { label: 'Financieel Risico',      value: crit,             Icon: AlertTriangle, color: '#c0392b', bg: 'rgba(192,57,43,0.1)' },
        { label: 'Open Risico\'s',         value: openRisks,        Icon: Shield, color: '#d97706', bg: 'rgba(217,119,6,0.1)' },
        { label: 'Leveranciers',           value: vendors.length,   Icon: Building2, color: '#154273', bg: 'rgba(21,66,115,0.1)' },
      ]
    : persona === 'po'
    ? [
        { label: 'Gem. Adoptie', value: vendors.length ? Math.round(vendors.reduce((a,v) => a+(v.adoption_rate||0),0)/vendors.length)+'%' : '–', Icon: TrendingUp, color: '#6d3fc0', bg: 'rgba(109,63,192,0.1)' },
        { label: 'Kritieke Adoptie <50%', value: vendors.filter(v=>(v.adoption_rate||0)<50).length, Icon: AlertTriangle, color: '#c0392b', bg: 'rgba(192,57,43,0.1)' },
        { label: 'Gelicentieerde Gebruikers', value: vendors.reduce((a,v)=>a+(v.licensed_users||0),0).toLocaleString('nl-NL'), Icon: Building2, color: '#154273', bg: 'rgba(21,66,115,0.1)' },
        { label: 'Actieve Gebruikers', value: vendors.reduce((a,v)=>a+(v.active_users||0),0).toLocaleString('nl-NL'), Icon: TrendingUp, color: '#1a9e5c', bg: 'rgba(26,158,92,0.1)' },
        { label: 'Gem. VHS', value: avg, Icon: Shield, color: '#077a8a', bg: 'rgba(7,122,138,0.1)' },
      ]
    : [
        { label: 'Leveranciers',     value: vendors.length, Icon: Building2,    color: '#154273', bg: 'rgba(21,66,115,0.1)' },
        { label: 'Gem. VHS',         value: avg,            Icon: TrendingUp,   color: '#1a9e5c', bg: 'rgba(26,158,92,0.1)' },
        { label: 'Kritieke Alerts',  value: crit,           Icon: AlertTriangle,color: '#c0392b', bg: 'rgba(192,57,43,0.1)' },
        { label: 'Open Risico\'s',   value: openRisks,      Icon: Shield,       color: '#d97706', bg: 'rgba(217,119,6,0.1)' },
        { label: 'Totale Waarde',    value: fmtEur(totalVal), Icon: BarChart2,  color: '#c9a227', bg: 'rgba(201,162,39,0.12)' },
      ]

  return (
    <div>
      {/* Persona header */}
      <div className="flex items-center gap-3.5 bg-white border border-gray-200 rounded-xl px-5 py-4 mb-5 shadow-card">
        <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-syne font-extrabold text-sm shrink-0" style={{ background: pa.color }}>
          {pa.initials}
        </div>
        <div>
          <div className="font-syne text-[14px] font-extrabold text-gray-900">{pa.name}</div>
          <div className="text-[10px] text-gray-400 mt-0.5">{pa.role}</div>
        </div>
        <div className="ml-auto text-[10px] font-semibold text-gov bg-gov-light px-3 py-1 rounded-full">{pa.focus}</div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-5 gap-3 mb-5">
        {kpis.map((k, i) => <KpiCard key={i} {...k} delay={i * 0.06} />)}
      </div>

      {/* Value Tracker (PO) */}
      {persona === 'po' && (
        <div>
          <SectionHeader title="Adoptie & Waarde Monitor" sub="Lever de software wat beloofd is?" />
          <div className="grid grid-cols-3 gap-3">
            {vendors.map((v, i) => {
              const pct = v.adoption_rate ?? 0
              const color = pct >= 70 ? '#1a9e5c' : pct >= 50 ? '#d97706' : '#c0392b'
              const radius = 26, cx = 32, cy = 32, circ = 2*Math.PI*radius, dash = (pct/100)*circ
              return (
                <Card key={v.id} className="p-3.5 fade-up" style={{ animationDelay: `${i*0.05}s` }}>
                  <div className="font-bold text-[12px] text-gray-900 mb-0.5">{vName(v)}</div>
                  <div className="text-[9px] text-gray-400 mb-2">PO: {v.product_owner || '–'}</div>
                  <div className="flex items-center gap-3">
                    <svg width="64" height="64" viewBox="0 0 64 64">
                      <circle cx={cx} cy={cy} r={radius} fill="none" stroke="#f1f3f7" strokeWidth="6"/>
                      <circle cx={cx} cy={cy} r={radius} fill="none" stroke={color} strokeWidth="6"
                        strokeDasharray={`${dash} ${circ-dash}`} strokeDashoffset={circ*0.25} strokeLinecap="round"/>
                      <text x={cx} y={cy+4} textAnchor="middle" fontSize="11" fontWeight="700" fill={color} fontFamily="DM Mono,monospace">{pct}%</text>
                    </svg>
                    <div className="text-[10px] text-gray-600 leading-6">
                      <div><strong>{v.active_users?.toLocaleString('nl-NL')}</strong> actief</div>
                      <div className="text-gray-400">{v.licensed_users?.toLocaleString('nl-NL')} gelicentieerd</div>
                      <div style={{ color, fontSize: 9, fontWeight: 600 }}>{pct < 50 ? '⚠ Lage adoptie' : '✓ Op peil'}</div>
                    </div>
                  </div>
                  <div className="mt-2">
                    <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bar-fill" style={{ width: `${pct}%`, background: color }} />
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      )}

      {/* CM / CE vendor grid + matrix */}
      {persona !== 'po' && (
        <div className="grid grid-cols-[1fr_260px] gap-5 items-start">
          <div>
            <SectionHeader title="Leveranciers" sub={`${filtered.length} van ${vendors.length}`}>
              <FilterGroup
                options={[{value:'all',label:'Alle'},{value:'green',label:'Gezond'},{value:'amber',label:'Waarschuwing'},{value:'red',label:'Kritiek'}]}
                active={ragFilter}
                onChange={setRagFilter}
              />
            </SectionHeader>
            {isLoading
              ? <LoadingGrid cols={2} rows={3} />
              : filtered.length
                ? <div className="grid grid-cols-2 gap-3">
                    {filtered.map((v, i) => (
                      <div key={v.id} className="fade-up" style={{ animationDelay: `${i*0.05}s` }}>
                        <VendorCard
                          vendor={v}
                          onOpen={setSelectedVendor}
                          onPlaybook={setPlaybookVendor}
                        />
                      </div>
                    ))}
                  </div>
                : <Empty message="Geen leveranciers gevonden." />
            }
          </div>

          {/* Right panel */}
          <div className="flex flex-col gap-3">
            <Card className="p-4">
              <div className="text-[12px] font-bold text-gray-900 mb-1">Kraljic Portfolio Matrix</div>
              <KraljicMatrix vendors={vendors} />
              <div className="text-[9px] text-gray-400 mt-2 pt-2 border-t border-gray-100 flex flex-col gap-1">
                <div>↑ Hoog leveringsrisico (boven)</div>
                <div>→ Hoge financiële impact (links)</div>
              </div>
            </Card>
            <Card className="p-4">
              <div className="text-[12px] font-bold text-gray-900 mb-2">VHS Legenda <span className="text-[9px] text-gray-400 font-normal">(V5.1)</span></div>
              {[{color:'#1a9e5c',bg:'#eaf7f1',range:'70–100',label:'Gezond'},{color:'#d97706',bg:'#fef3e0',range:'50–69',label:'Waarschuwing'},{color:'#c0392b',bg:'#fdecea',range:'0–49',label:'Kritiek → Playbook'}].map(l => (
                <div key={l.range} className="flex items-center gap-1.5 text-[10px] text-gray-600 mb-1">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ background: l.color }} />
                  <span className="font-mono font-semibold" style={{ color: l.color, minWidth: 40 }}>{l.range}</span>
                  <span>{l.label}</span>
                </div>
              ))}
              <div className="text-[9px] text-gray-400 pt-2 mt-1 border-t border-gray-100 leading-relaxed">
                Compliance 35% · Performance 35% · Adoptie 20% · Sentiment 10%
              </div>
            </Card>
          </div>
        </div>
      )}

      <VendorDrawer
        vendorId={selectedVendor}
        onClose={() => setSelectedVendor(null)}
        onPlaybook={setPlaybookVendor}
      />
      <PlaybookModal
        vendor={playbookVendor}
        onClose={() => setPlaybookVendor(null)}
        onActivate={() => { setPlaybookVendor(null); toast('✓ Playbook geactiveerd — acties aangemaakt in Risk Log.') }}
      />
    </div>
  )
}
