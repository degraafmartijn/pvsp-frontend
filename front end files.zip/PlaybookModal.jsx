import { Modal, Button } from '@/components/ui'
import { calcScore, vName } from '@/lib/utils'
import { AlertTriangle, Zap } from 'lucide-react'

export default function PlaybookModal({ vendor, onClose, onActivate }) {
  if (!vendor) return null
  const score = vendor.health_score ?? 0

  const risks = vendor.risk_entries?.filter(r => r.status === 'open') || []
  const adoptPct = vendor.adoption_rate ?? 0
  const trend = 'dalend'  // would be computed from history

  const evidenceLines = [
    `📋 VHS score: ${score} (drempelwaarde: 50)`,
    `📊 Adoptie: ${vendor.active_users ?? '–'}/${vendor.licensed_users ?? '–'} gebruikers (${adoptPct}%)`,
    `⚠ Open risico's: ${risks.length}${risks.length > 0 ? ` — ${risks[0]?.signal}` : ''}`,
    `🏛 Domein: ${vendor.vendor_domains?.[0]?.domain_name ?? vendor.domain ?? '–'} · Categorie: ${vendor.kraljic_category}`,
    score < 40
      ? `🔴 Score <40: concept-ingebrekestelling wordt aangemaakt door AI.`
      : `🟡 Score 40–50: escalatieprocedure gestart.`,
  ]

  return (
    <Modal
      open={!!vendor}
      onClose={onClose}
      title={
        <span className="flex items-center gap-2">
          <AlertTriangle size={14} /> Underperformance Intervention Playbook
        </span>
      }
      headerColor="#c0392b"
      width={480}
    >
      <div>
        <div className="text-[9px] uppercase tracking-widest text-gray-400">Leverancier</div>
        <div className="text-[14px] font-bold text-gray-900 mt-0.5">{vName(vendor)}</div>
      </div>

      {/* Score box */}
      <div className="bg-red-bg border border-red/20 rounded-xl p-3 flex items-center gap-3">
        <span className="text-[34px] font-black font-syne text-red leading-none">{score}</span>
        <div>
          <div className="text-[10px] font-bold text-red mb-0.5">VHS onder drempelwaarde (50) — V5.1</div>
          <div className="text-[10px] text-red/80">Compliance 35% · Performance 35% · Adoptie 20% · Sentiment 10%</div>
        </div>
      </div>

      {/* AI evidence */}
      <div className="bg-gold-bg border border-gold/30 rounded-xl p-3">
        <div className="text-[9px] font-bold uppercase tracking-widest text-gold flex items-center gap-1.5 mb-2">
          <Zap size={10} /> AI verzamelt bewijslast automatisch
        </div>
        <div className="text-[10px] text-yellow-800 leading-7 space-y-0.5">
          {evidenceLines.map((l, i) => <div key={i}>{l}</div>)}
        </div>
      </div>

      {/* Steps */}
      <div>
        <div className="text-[9px] uppercase tracking-widest text-gray-400 font-bold mb-2">Stappenplan interventie</div>
        <div className="flex flex-col gap-1.5">
          {[
            'AI stelt agenda op voor Tactisch Overleg (QBR urgent)',
            'Escalatiegesprek plannen binnen 5 werkdagen',
            'Compliance-audit initiëren (DPO betrekken, GIBIT check)',
            'SLA-clausules herbevestigen + MTTR meten',
            score < 40 ? 'Concept-ingebrekestelling voorbereiden — AI genereert draft' : 'Contingency plan activeren indien score <40',
            'Stakeholder update sturen naar Contract Eigenaar',
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-2 text-[10px] text-gray-600">
              <span className="shrink-0 w-[17px] h-[17px] rounded-full bg-red-bg text-red flex items-center justify-center text-[8px] font-bold mt-0.5">
                {i + 1}
              </span>
              <span className={i === 4 && score < 40 ? 'text-red font-semibold' : ''}>{step}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2 pt-1">
        <Button variant="primary" className="flex-1" onClick={onActivate}>
          {score < 40 ? 'Playbook + Ingebrekestelling Activeren' : 'Playbook Activeren'}
        </Button>
        <Button variant="secondary" className="flex-1" onClick={onClose}>
          Annuleren
        </Button>
      </div>
    </Modal>
  )
}
