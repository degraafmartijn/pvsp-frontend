import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import * as api from '@/api/client'

// ── Vendors ─────────────────────────────────────────────────────
export const useVendors = (params) =>
  useQuery({ queryKey: ['vendors', params], queryFn: () => api.fetchVendors(params) })

export const useVendor = (id) =>
  useQuery({ queryKey: ['vendor', id], queryFn: () => api.fetchVendor(id), enabled: !!id })

export const useCreateVendor = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.createVendor,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['vendors'] }),
  })
}

export const useUpdateVendor = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.updateVendor(id, data),
    onSuccess: (_, { id }) => {
      qc.invalidateQueries({ queryKey: ['vendors'] })
      qc.invalidateQueries({ queryKey: ['vendor', id] })
    },
  })
}

// ── Health ──────────────────────────────────────────────────────
export const useHealthHistory = (vendorId, limit = 12) =>
  useQuery({
    queryKey: ['health', vendorId, limit],
    queryFn: () => api.fetchHealth(vendorId, limit),
    enabled: !!vendorId,
  })

export const useRecordHealth = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ vendorId, data }) => api.recordHealth(vendorId, data),
    onSuccess: (_, { vendorId }) => {
      qc.invalidateQueries({ queryKey: ['health', vendorId] })
      qc.invalidateQueries({ queryKey: ['vendor', vendorId] })
      qc.invalidateQueries({ queryKey: ['summary'] })
    },
  })
}

// ── Compliance ──────────────────────────────────────────────────
export const useCompliance = (vendorId) =>
  useQuery({
    queryKey: ['compliance', vendorId],
    queryFn: () => api.fetchCompliance(vendorId),
    enabled: !!vendorId,
  })

export const useUpsertCompliance = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ vendorId, data }) => api.upsertCompliance(vendorId, data),
    onSuccess: (_, { vendorId }) => qc.invalidateQueries({ queryKey: ['compliance', vendorId] }),
  })
}

// ── Risks ───────────────────────────────────────────────────────
export const useRisks = (params) =>
  useQuery({ queryKey: ['risks', params], queryFn: () => api.fetchRisks(params) })

export const useUpdateRisk = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.updateRisk(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['risks'] }),
  })
}

// ── Tasks ───────────────────────────────────────────────────────
export const useTasks = (params) =>
  useQuery({ queryKey: ['tasks', params], queryFn: () => api.fetchTasks(params) })

export const useCreateTask = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.createTask,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  })
}

export const useUpdateTask = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }) => api.updateTask(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  })
}

export const useDeleteTask = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: api.deleteTask,
    onSuccess: () => qc.invalidateQueries({ queryKey: ['tasks'] }),
  })
}

// ── Renewal ─────────────────────────────────────────────────────
export const useRenewalFunnel = () =>
  useQuery({ queryKey: ['renewal-funnel'], queryFn: api.fetchRenewalFunnel })

export const useExpiringContracts = (days = 90) =>
  useQuery({ queryKey: ['expiring', days], queryFn: () => api.fetchExpiringContracts(days) })

// ── Meetings ────────────────────────────────────────────────────
export const useMeetings = (vendorId) =>
  useQuery({
    queryKey: ['meetings', vendorId],
    queryFn: () => api.fetchMeetings(vendorId),
    enabled: !!vendorId,
  })

export const useCreateMeeting = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ vendorId, data }) => api.createMeeting(vendorId, data),
    onSuccess: (_, { vendorId }) => qc.invalidateQueries({ queryKey: ['meetings', vendorId] }),
  })
}

// ── Dashboard summary ───────────────────────────────────────────
export const useSummary = () =>
  useQuery({ queryKey: ['summary'], queryFn: api.fetchSummary })

// ── Domains ─────────────────────────────────────────────────────
export const useDomains = () =>
  useQuery({ queryKey: ['domains'], queryFn: api.fetchDomains })
