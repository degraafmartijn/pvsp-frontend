// ── TaskModal.jsx ──────────────────────────────────────────────────
import { useState } from 'react'
import { Modal, Input, Select, Textarea, Button } from '@/components/ui'
import { useCreateTask } from '@/hooks/useVendors'
import { useVendors } from '@/hooks/useVendors'
import { vName } from '@/lib/utils'
import { Plus } from 'lucide-react'

export function TaskModal({ open, onClose, defaultStatus = 'open' }) {
  const [form, setForm] = useState({
    title: '', category: 'Compliance', vendor_id: '', assignee: '',
    priority: 'medium', status: defaultStatus, due_date: '', source: 'handmatig',
  })
  const create = useCreateTask()
  const { data: vendors = [] } = useVendors()

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  const save = async () => {
    if (!form.title.trim()) return
    await create.mutateAsync({ ...form, vendor_id: form.vendor_id ? +form.vendor_id : null })
    onClose()
    setForm({ title: '', category: 'Compliance', vendor_id: '', assignee: '', priority: 'medium', status: defaultStatus, due_date: '', source: 'handmatig' })
  }

  return (
    <Modal
      open={open} onClose={onClose}
      title={<span className="flex items-center gap-2"><Plus size={13} /> Nieuwe Taak Aanmaken</span>}
      headerColor="#154273"
      width={440}
    >
      <Input
        label="Taakomschrijving *"
        placeholder="Bijv: Compliance audit inplannen voor…"
        value={form.title}
        onChange={e => set('title', e.target.value)}
      />
      <div className="grid grid-cols-2 gap-2.5">
        <Select label="Leverancier" value={form.vendor_id} onChange={e => set('vendor_id', e.target.value)}>
          <option value="">– Geen specifiek –</option>
          {vendors.map(v => <option key={v.id} value={v.id}>{vName(v)}</option>)}
        </Select>
        <Select label="Toegewezen aan" value={form.assignee} onChange={e => set('assignee', e.target.value)}>
          <option value="">– Niet toegewezen –</option>
          {['A. Smit', 'C. Bakker', 'B. de Jong', 'Contract Manager'].map(a => <option key={a}>{a}</option>)}
        </Select>
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        <Select label="Categorie" value={form.category} onChange={e => set('category', e.target.value)}>
          {['Compliance','Contract','Renewal','Governance','Budget','VHS Kritiek','Overig'].map(c => <option key={c}>{c}</option>)}
        </Select>
        <Select label="Prioriteit" value={form.priority} onChange={e => set('priority', e.target.value)}>
          <option value="hoog">🔴 Hoog</option>
          <option value="medium">🟡 Medium</option>
          <option value="laag">🟢 Laag</option>
        </Select>
      </div>
      <Input label="Deadline" type="date" value={form.due_date} onChange={e => set('due_date', e.target.value)} />
      <div className="flex gap-2 pt-1">
        <Button variant="primary" className="flex-2 flex-1" onClick={save} disabled={create.isPending}>
          {create.isPending ? 'Opslaan…' : 'Taak Opslaan'}
        </Button>
        <Button variant="secondary" className="flex-1" onClick={onClose}>Annuleren</Button>
      </div>
    </Modal>
  )
}
