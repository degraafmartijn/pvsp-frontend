/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        gov: {
          DEFAULT: '#154273',
          dark:    '#0d2d52',
          mid:     '#1c5491',
          light:   '#e8f0fa',
        },
        gold:   { DEFAULT: '#c9a227', bg: '#fef8e7' },
        green:  { DEFAULT: '#1a9e5c', bg: '#eaf7f1' },
        amber:  { DEFAULT: '#d97706', bg: '#fef3e0' },
        red:    { DEFAULT: '#c0392b', bg: '#fdecea' },
        purple: { DEFAULT: '#6d3fc0', bg: '#f0eafb' },
        teal:   { DEFAULT: '#0e7c87', bg: '#e0f5f7' },
      },
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        mono: ['DM Mono', 'monospace'],
        syne: ['Syne', 'sans-serif'],
      },
      borderRadius: { DEFAULT: '12px' },
      boxShadow: {
        card: '0 2px 12px rgba(21,66,115,0.08)',
        'card-md': '0 4px 24px rgba(21,66,115,0.13)',
      },
    },
  },
  plugins: [],
}
