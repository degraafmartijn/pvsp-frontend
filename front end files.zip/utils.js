// ── VHS weights V5.1 ─────────────────────────────────────────────
export const VHS_WEIGHTS = { c: 0.35, p: 0.35, a: 0.20, s: 0.10 }

export function calcScore({ c = 0, p = 0, a = 50, s = 50 }) {
  const clamp = (v) => Math.max(0, Math.min(100, +v))
  return +(clamp(c) * VHS_WEIGHTS.c + clamp(p) * VHS_WEIGHTS.p +
           clamp(a) * VHS_WEIGHTS.a + clamp(s) * VHS_WEIGHTS.s).toFixed(1)
}

export function rag(score) {
  if (score >= 70) return 'green'
  if (score >= 50) return 'amber'
  return 'red'
}

export const RAG_COLOR  = { green: '#1a9e5c', amber: '#d97706', red: '#c0392b' }
export const RAG_BG     = { green: '#eaf7f1', amber: '#fef3e0', red: '#fdecea' }
export const RAG_BORDER = { green: '#a8e6c8', amber: '#fde68a', red: '#f5c5c0' }

export function ragClasses(score) {
  const r = rag(score)
  return {
    green: 'text-green-600 bg-green-50',
    amber: 'text-amber-600 bg-amber-50',
    red:   'text-red-600 bg-red-50',
  }[r]
}

// ── Formatting ─────────────────────────────────────────────────────
export function fmtEur(v) {
  if (v >= 1_000_000) return `€${(v / 1_000_000).toFixed(1)}M`
  if (v >= 1_000)     return `€${(v / 1_000).toFixed(0)}K`
  return `€${v}`
}

export function daysLeft(dateStr) {
  return Math.ceil((new Date(dateStr) - new Date()) / 86_400_000)
}

export function predictScore(history) {
  const n = history.length
  const slope = (history[n - 1] - history[0]) / (n - 1)
  return [1, 2, 3].map((i) =>
    Math.round(Math.max(0, Math.min(100, history[n - 1] + slope * i)))
  )
}

export function complianceScore(c) {
  if (!c) return null
  const checks = [
    [c.nis2_compliant, 15], [c.gibit_applicable, 15], [c.bio_compliant, 15],
    [c.iso_27001_certified, 20], [c.iso_9001_certified, 10],
    [c.soc2_report, 15], [c.dpia_performed, 10],
  ]
  const score = checks.reduce((sum, [v, w]) => sum + (v ? w : 0), 0)
  const max   = checks.reduce((sum, [, w]) => sum + w, 0)
  return Math.round((score / max) * 100)
}

// Vendor display name
export const vName = (v) => v?.trade_name || v?.legal_name || '–'

// Earliest active contract end date
export function vEnd(v) {
  const contracts = v?.contracts || []
  if (!contracts.length) return null
  const active = contracts.filter((c) => c.status !== 'beëindigd')
  const list = active.length ? active : contracts
  return list.sort((a, b) => new Date(a.end_date) - new Date(b.end_date))[0].end_date
}

export const clsx = (...args) =>
  args.flat().filter(Boolean).join(' ')
