import { useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from '@/components/layout/Sidebar'
import Topbar  from '@/components/layout/Topbar'
import { ToastProvider } from '@/components/ui'
import { TaskModal } from '@/components/tasks/TaskModal'

// Views
import DashboardView  from '@/views/DashboardView'
import ManagerView    from '@/views/ManagerView'
import VendorsView    from '@/views/VendorsView'
import RenewalView    from '@/views/RenewalView'
import GovernanceView from '@/views/GovernanceView'
import RiskLogView    from '@/views/RiskLogView'
import AIToolsView    from '@/views/AIToolsView'
import AlertsView     from '@/views/AlertsView'
import AnalyticsView  from '@/views/AnalyticsView'
import TasksView      from '@/views/TasksView'

export default function App() {
  const [persona,       setPersona]       = useState('cm')
  const [search,        setSearch]        = useState('')
  const [taskModalOpen, setTaskModalOpen] = useState(false)

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar persona={persona} setPersona={setPersona} />

      <div className="flex-1 flex flex-col" style={{ marginLeft: 228 }}>
        <Topbar
          search={search}
          setSearch={setSearch}
          onNewTask={() => setTaskModalOpen(true)}
        />

        <main className="flex-1 p-7 overflow-y-auto">
          <Routes>
            <Route path="/"           element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard"  element={<DashboardView  persona={persona} search={search} />} />
            <Route path="/manager"    element={<ManagerView />} />
            <Route path="/vendors"    element={<VendorsView    search={search} />} />
            <Route path="/renewal"    element={<RenewalView />} />
            <Route path="/governance" element={<GovernanceView />} />
            <Route path="/risklog"    element={<RiskLogView />} />
            <Route path="/aitools"    element={<AIToolsView />} />
            <Route path="/alerts"     element={<AlertsView />} />
            <Route path="/analytics"  element={<AnalyticsView />} />
            <Route path="/tasks"      element={<TasksView onNewTask={() => setTaskModalOpen(true)} />} />
            <Route path="*"           element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>

      <TaskModal open={taskModalOpen} onClose={() => setTaskModalOpen(false)} />
      <ToastProvider />
    </div>
  )
}
