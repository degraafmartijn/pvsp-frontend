import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutGrid, Building2, RefreshCw, Users, AlertTriangle,
  Zap, Bell, BarChart2, CheckSquare, Shield,
} from 'lucide-react'
import { useTasks } from '@/hooks/useVendors'
import { useRisks } from '@/hooks/useVendors'
import { clsx } from '@/lib/utils'

const PERSONAS = {
  cm: { label: 'CM', name: 'Annet – Contract Manager',   role: 'Action Center',        color: '#154273' },
  ce: { label: 'CE', name: 'Bas – Contract Eigenaar',    role: 'Strategische Horizon', color: '#6d3fc0' },
  po: { label: 'PO', name: 'Mark – Product Owner',       role: 'Value Tracker',        color: '#077a8a' },
}

export default function Sidebar({ persona, setPersona }) {
  const { data: tasks  = [] } = useTasks({ status: 'open' })
  const { data: risks  = [] } = useRisks({ status: 'open', level: 'high' })

  const navItem = (to, Icon, label, badge = null) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        clsx(
          'flex items-center gap-2.5 px-3 py-2 rounded-[7px] text-[12px] font-medium transition-all',
          isActive
            ? 'bg-white/16 text-white font-bold'
            : 'text-white/55 hover:bg-white/8 hover:text-white/90'
        )
      }
    >
      <Icon size={13} className="shrink-0" />
      <span className="flex-1">{label}</span>
      {badge !== null && badge > 0 && (
        <span className="bg-red text-white rounded-full text-[9px] font-bold px-1.5 py-0.5 leading-none">{badge}</span>
      )}
    </NavLink>
  )

  const pa = PERSONAS[persona]

  return (
    <aside className="w-[228px] min-h-screen bg-gov flex flex-col fixed top-0 left-0 z-[100]">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-white/10 flex items-center gap-3">
        <div className="w-8 h-8 bg-gold rounded-lg flex items-center justify-center shrink-0">
          <Shield size={15} className="text-white" />
        </div>
        <div>
          <div className="text-white font-syne text-sm font-extrabold tracking-wider">
            PVSP{' '}
            <span className="text-[10px] font-bold bg-gold text-white rounded px-1 py-0.5 align-middle">V5.1</span>
          </div>
          <div className="text-white/40 text-[9px] uppercase tracking-widest mt-0.5">Overheid Platform</div>
        </div>
      </div>

      <nav className="flex-1 px-2 py-3 flex flex-col gap-0.5 overflow-y-auto">
        {/* Dashboards section */}
        <div className="px-2.5 py-2 text-[9px] uppercase tracking-widest text-white/30 font-bold">Dashboards</div>

        {/* Persona switcher */}
        <div className="flex gap-1 px-1 pb-2">
          {Object.entries(PERSONAS).map(([key, p]) => (
            <button
              key={key}
              onClick={() => setPersona(key)}
              title={`${p.name} – ${p.role}`}
              className={clsx(
                'flex-1 py-1.5 rounded-md text-[10px] font-bold border transition-all cursor-pointer',
                persona === key
                  ? 'bg-white text-gov border-white'
                  : 'bg-white/10 text-white/60 border-white/20 hover:bg-white/18 hover:text-white'
              )}
            >
              {p.label}
            </button>
          ))}
        </div>

        {navItem('/dashboard', LayoutGrid, 'Dashboard')}
        {navItem('/manager',   Users,      'Manager Dashboard')}

        <div className="px-2.5 py-2 mt-1 text-[9px] uppercase tracking-widest text-white/30 font-bold">Beheer</div>
        {navItem('/vendors',    Building2,  'Leveranciers')}
        {navItem('/renewal',    RefreshCw,  'Renewal Funnel')}
        {navItem('/tasks',      CheckSquare,'Taken & Playbooks', tasks.length)}

        <div className="px-2.5 py-2 mt-1 text-[9px] uppercase tracking-widest text-white/30 font-bold">Governance</div>
        {navItem('/governance', Users,      'Overlegmatrix')}
        {navItem('/risklog',    AlertTriangle,'Risk Log', risks.length)}

        <div className="px-2.5 py-2 mt-1 text-[9px] uppercase tracking-widest text-white/30 font-bold">AI Functies</div>
        {navItem('/aitools',   Zap,        'AI Gereedschappen')}
        {navItem('/alerts',    Bell,       'Meldingen')}
        {navItem('/analytics', BarChart2,  'Analyses')}
      </nav>

      {/* User footer */}
      <div className="px-3 py-3 border-t border-white/10">
        <div className="flex items-center gap-2.5 px-1">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-white text-[10px] font-black shrink-0"
            style={{ background: pa.color }}
          >
            {pa.label}
          </div>
          <div className="min-w-0">
            <div className="text-white text-[11px] font-semibold truncate">{pa.name.split('–')[0].trim()}</div>
            <div className="text-white/40 text-[9px]">{pa.role}</div>
          </div>
        </div>
      </div>
    </aside>
  )
}
