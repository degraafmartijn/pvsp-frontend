import { useVendors, useRisks } from '@/hooks/useVendors'
import { useNavigate }           from 'react-router-dom'
import { Button, SectionHeader } from '@/components/ui'
import { rag, vName, vEnd, daysLeft } from '@/lib/utils'
import { AlertTriangle }          from 'lucide-react'

export default function AlertsView() {
  const { data: vendors = [] } = useVendors()
  const { data: highRisks = [] } = useRisks({ status: 'open', level: 'high' })
  const navigate = useNavigate()

  const alerts = []
  vendors.forEach(v => {
    const score = v.health_score ?? 50
    const endDate = vEnd(v)
    const days = endDate ? daysLeft(endDate) : null

    if (score < 50) alerts.push({
      color: '#c0392b', bg: '#fdecea',
      title: `Kritieke Health Score: ${vName(v)}`,
      desc: `Score ${score}/100 — onder drempelwaarde van 50. Playbook activering aanbevolen.`,
      tag: 'Kritiek',
      action: () => navigate('/vendors'),
      actionLabel: 'Naar Leveranciers',
    })
    if (days !== null && days > 0 && days <= 90) alerts.push({
      color: '#d97706', bg: '#fef3e0',
      title: `Contract verloopt: ${vName(v)}`,
      desc: `Contract verloopt over ${days} dag${days !== 1 ? 'en' : ''}. Start renewal procedure.`,
      tag: 'Verloping',
      action: () => navigate('/renewal'),
      actionLabel: 'Renewal Funnel',
    })
  })

  highRisks.forEach(r => alerts.push({
    color: '#c0392b', bg: '#fdecea',
    title: `Hoog Risico: ${r.signal}`,
    desc: `Leverancier: ${r.vendor} · Bron: ${r.source} · ${r.clause}`,
    tag: 'Risico',
    action: () => navigate('/risklog'),
    actionLabel: 'Bekijk Risk Log',
  }))

  return (
    <div className="max-w-[840px]">
      <SectionHeader title="Actieve Meldingen" sub={`${alerts.length} actief`} />
      {alerts.length === 0 && (
        <div className="py-16 text-center text-gray-400">Geen actieve meldingen.</div>
      )}
      <div className="flex flex-col gap-2.5">
        {alerts.map((a, i) => (
          <div key={i}
            className="bg-white border border-gray-200 rounded-xl shadow-card flex items-start gap-3.5 p-3.5 fade-up"
            style={{ borderLeft: `4px solid ${a.color}`, animationDelay: `${i*0.06}s` }}
          >
            <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: a.bg }}>
              <AlertTriangle size={14} style={{ color: a.color }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[12px] font-bold text-gray-900">{a.title}</div>
              <div className="text-[10px] text-gray-600 mt-0.5 leading-snug">{a.desc}</div>
              <div className="text-[9px] text-gray-400 mt-1.5">Ministerie BZK · {new Date().toLocaleDateString('nl-NL')}</div>
            </div>
            <div className="flex flex-col items-end gap-1.5 shrink-0">
              <span className="text-[9px] font-bold uppercase px-2 py-0.5 rounded-full" style={{ background: a.bg, color: a.color }}>{a.tag}</span>
              <Button size="sm" onClick={a.action}>{a.actionLabel}</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
