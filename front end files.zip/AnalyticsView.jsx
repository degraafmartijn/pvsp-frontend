import { useVendors } from '@/hooks/useVendors'
import { Card, SectionHeader } from '@/components/ui'
import { rag, RAG_COLOR, fmtEur, vName } from '@/lib/utils'

const KM_COLORS = { strategic:'#154273', leverage:'#077a8a', bottleneck:'#c0392b', routine:'#5c6575' }
const LC_COLORS = { onboarding:'#6d3fc0', active:'#1a9e5c', renewal:'#d97706', exit:'#c0392b' }
const LC_LABELS = { onboarding:'Onboarding', active:'Actief', renewal:'Renewal', exit:'Exit' }

function BarChart({ items, height = 130 }) {
  const max = Math.max(...items.map(i => i.value), 1)
  return (
    <div className="flex items-end gap-2" style={{ height }}>
      {items.map((item, i) => {
        const h = Math.max(8, Math.round((item.value / max) * (height - 24)))
        return (
          <div key={i} className="flex flex-col items-center gap-1 flex-1">
            <span className="text-[9px] font-mono font-semibold" style={{ color: item.color }}>{item.label}</span>
            <div className="w-full rounded-t-[4px] cursor-pointer hover:brightness-90 transition-all" style={{ height: h, background: item.color }} title={`${item.name}: ${item.label}`} />
            <span className="text-[8px] text-gray-400 text-center max-w-[48px] leading-tight word-break-break-word">{item.name}</span>
          </div>
        )
      })}
    </div>
  )
}

function DonutChart({ slices, total }) {
  let cumAngle = 0
  const paths = slices.map(s => {
    const start = cumAngle
    const angle = s.frac * 360
    cumAngle += angle
    if (angle >= 360) return { ...s, path: `M 60 10 A 50 50 0 1 1 59.99 10 Z`, start }
    const toRad = (a) => ((a - 90) * Math.PI) / 180
    const x1 = 60 + 50 * Math.cos(toRad(start))
    const y1 = 60 + 50 * Math.sin(toRad(start))
    const x2 = 60 + 50 * Math.cos(toRad(start + angle))
    const y2 = 60 + 50 * Math.sin(toRad(start + angle))
    const ix1 = 60 + 28 * Math.cos(toRad(start + angle))
    const iy1 = 60 + 28 * Math.sin(toRad(start + angle))
    const ix2 = 60 + 28 * Math.cos(toRad(start))
    const iy2 = 60 + 28 * Math.sin(toRad(start))
    const large = angle > 180 ? 1 : 0
    return { ...s, path: `M${x1},${y1} A50,50,0,${large},1,${x2},${y2} L${ix1},${iy1} A28,28,0,${large},0,${ix2},${iy2} Z` }
  })
  return (
    <div className="flex items-center gap-4 justify-center">
      <svg width="120" height="120" viewBox="0 0 120 120">
        {paths.map((s, i) => <path key={i} d={s.path} fill={s.color} opacity="0.9" />)}
        <circle cx="60" cy="60" r="22" fill="white" />
        <text x="60" y="57" textAnchor="middle" fontSize="13" fontWeight="700" fill="#1a1f2e" fontFamily="Syne,sans-serif">{total}</text>
        <text x="60" y="68" textAnchor="middle" fontSize="8" fill="#9aa3b0" fontFamily="DM Sans,sans-serif">vendors</text>
      </svg>
      <div className="flex flex-col gap-1.5">
        {paths.map((s, i) => (
          <div key={i} className="flex items-center gap-2 text-[10px] text-gray-600">
            <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: s.color }} />
            <span>{s.name}</span>
            <strong className="ml-auto font-mono text-[11px]">{s.count}</strong>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function AnalyticsView() {
  const { data: vendors = [] } = useVendors()
  const sorted = [...vendors].sort((a, b) => (b.health_score ?? 0) - (a.health_score ?? 0))

  // Donut: Kraljic
  const catCounts = {}
  vendors.forEach(v => catCounts[v.kraljic_category] = (catCounts[v.kraljic_category] || 0) + 1)
  const total = vendors.length || 1
  const KM_LABELS = { strategic:'Strategisch', leverage:'Hefboom', bottleneck:'Knelpunt', routine:'Routine' }
  const donutSlices = Object.entries(catCounts).map(([cat, cnt]) => ({
    name: KM_LABELS[cat] || cat, color: KM_COLORS[cat], frac: cnt/total, count: cnt
  }))

  // Lifecycle
  const lcCounts = {}
  vendors.forEach(v => lcCounts[v.lifecycle_stage] = (lcCounts[v.lifecycle_stage] || 0) + 1)

  // Risk (mock from summary)
  const riskData = [
    { name:'Open',       value:3, label:'3', color:'#c0392b' },
    { name:'Behandeling',value:2, label:'2', color:'#d97706' },
    { name:'Afgehandeld',value:2, label:'2', color:'#1a9e5c' },
  ]

  return (
    <div className="max-w-[880px]">
      <SectionHeader title="Portfolio Analyse" />
      <div className="grid grid-cols-2 gap-4">
        <Card className="p-4 fade-up">
          <div className="text-[12px] font-bold text-gray-900 mb-3">Health Score per Leverancier</div>
          <BarChart items={sorted.map(v => ({ name: vName(v).split(' ')[0], value: v.health_score ?? 50, label: String(v.health_score ?? 50), color: RAG_COLOR[rag(v.health_score ?? 50)] }))} />
        </Card>

        <Card className="p-4 fade-up" style={{ animationDelay: '0.08s' }}>
          <div className="text-[12px] font-bold text-gray-900 mb-3">Kraljic Portfolio Verdeling</div>
          <DonutChart slices={donutSlices} total={vendors.length} />
        </Card>

        <Card className="p-4 fade-up" style={{ animationDelay: '0.12s' }}>
          <div className="text-[12px] font-bold text-gray-900 mb-3">Lifecycle Fasen</div>
          <BarChart items={Object.entries(lcCounts).map(([lc, cnt]) => ({ name: LC_LABELS[lc] || lc, value: cnt, label: String(cnt), color: LC_COLORS[lc] || '#9aa3b0' }))} />
        </Card>

        <Card className="p-4 fade-up" style={{ animationDelay: '0.16s' }}>
          <div className="text-[12px] font-bold text-gray-900 mb-3">Risk Log Status</div>
          <BarChart items={riskData} />
        </Card>
      </div>
    </div>
  )
}
