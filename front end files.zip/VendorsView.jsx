// ── VendorsView.jsx ────────────────────────────────────────────────
import { useState } from 'react'
import { useVendors } from '@/hooks/useVendors'
import VendorCard   from '@/components/vendors/VendorCard'
import VendorDrawer from '@/components/vendors/VendorDrawer'
import PlaybookModal from '@/components/vendors/PlaybookModal'
import { SectionHeader, FilterGroup, LoadingGrid, Empty, useToast } from '@/components/ui'
import { rag, vName } from '@/lib/utils'

export function VendorsView({ search }) {
  const [ragFilter, setRagFilter] = useState('all')
  const [selectedVendor, setSelectedVendor] = useState(null)
  const [playbookVendor, setPlaybookVendor] = useState(null)
  const toast = useToast()
  const { data: vendors = [], isLoading } = useVendors()

  const filtered = vendors.filter(v => {
    const r = rag(v.health_score ?? 50)
    return (ragFilter === 'all' || r === ragFilter) &&
           vName(v).toLowerCase().includes((search||'').toLowerCase())
  })

  return (
    <div>
      <SectionHeader title="Alle Leveranciers" sub={`${filtered.length} van ${vendors.length}`}>
        <FilterGroup
          options={[{value:'all',label:'Alle'},{value:'green',label:'Gezond'},{value:'amber',label:'Waarschuwing'},{value:'red',label:'Kritiek'}]}
          active={ragFilter}
          onChange={setRagFilter}
        />
      </SectionHeader>
      {isLoading
        ? <LoadingGrid cols={3} rows={2} />
        : filtered.length
          ? <div className="grid grid-cols-3 gap-3">
              {filtered.map((v, i) => (
                <div key={v.id} className="fade-up" style={{ animationDelay: `${i*0.04}s` }}>
                  <VendorCard vendor={v} onOpen={setSelectedVendor} onPlaybook={setPlaybookVendor} />
                </div>
              ))}
            </div>
          : <Empty />
      }
      <VendorDrawer vendorId={selectedVendor} onClose={() => setSelectedVendor(null)} onPlaybook={setPlaybookVendor} />
      <PlaybookModal vendor={playbookVendor} onClose={() => setPlaybookVendor(null)}
        onActivate={() => { setPlaybookVendor(null); toast('✓ Playbook geactiveerd.') }} />
    </div>
  )
}

export default VendorsView
