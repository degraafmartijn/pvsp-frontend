import { forwardRef, useEffect, useRef, useState } from 'react'
import { X } from 'lucide-react'
import { RAG_COLOR, rag, clsx } from '@/lib/utils'

// ── Badge ──────────────────────────────────────────────────────────
export function Badge({ children, color = '#154273', bg, className = '' }) {
  return (
    <span
      className={`inline-block text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${className}`}
      style={{ background: bg || color + '18', color }}
    >
      {children}
    </span>
  )
}

// ── RAG Badge ─────────────────────────────────────────────────────
export function RagBadge({ score }) {
  const r = rag(score)
  const labels = { green: 'Gezond', amber: 'Waarschuwing', red: 'Kritiek' }
  const colors = { green: '#1a9e5c', amber: '#d97706', red: '#c0392b' }
  const bgs    = { green: '#eaf7f1', amber: '#fef3e0', red: '#fdecea' }
  return <Badge color={colors[r]} bg={bgs[r]}>{labels[r]}</Badge>
}

// ── Button ─────────────────────────────────────────────────────────
export function Button({ children, variant = 'primary', size = 'md', className = '', ...props }) {
  const base = 'inline-flex items-center gap-1.5 font-semibold rounded-lg transition-colors cursor-pointer border-0 font-sans'
  const sizes = { sm: 'text-[10px] px-3 py-1.5', md: 'text-xs px-4 py-2', lg: 'text-sm px-5 py-2.5' }
  const variants = {
    primary:   'bg-gov text-white hover:bg-gov-dark',
    secondary: 'bg-white text-gray-600 border border-gray-200 hover:border-gray-400',
    danger:    'bg-red text-white hover:bg-red-700',
    ghost:     'bg-transparent text-gov hover:bg-gov-light',
  }
  return (
    <button className={clsx(base, sizes[size], variants[variant], className)} {...props}>
      {children}
    </button>
  )
}

// ── Card ───────────────────────────────────────────────────────────
export function Card({ children, className = '', onClick }) {
  return (
    <div
      className={clsx(
        'bg-white border border-gray-200 rounded-xl shadow-card',
        onClick && 'cursor-pointer hover:shadow-card-md hover:-translate-y-0.5 transition-all duration-200',
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  )
}

// ── Spinner ────────────────────────────────────────────────────────
export function Spinner({ size = 16, color = 'white' }) {
  return (
    <span
      className="inline-block rounded-full border-2 animate-spin"
      style={{
        width: size, height: size,
        borderColor: `${color}44`,
        borderTopColor: color,
      }}
    />
  )
}

// ── Score Arc SVG ──────────────────────────────────────────────────
export function ScoreArc({ score, size = 56 }) {
  const r = rag(score)
  const color = RAG_COLOR[r]
  const radius = size * 0.39
  const cx = size / 2, cy = size / 2
  const circ = 2 * Math.PI * radius
  const dash = (score / 100) * circ
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="shrink-0">
      <circle cx={cx} cy={cy} r={radius} fill="none" stroke="#f1f3f7" strokeWidth="5" />
      <circle
        cx={cx} cy={cy} r={radius} fill="none"
        stroke={color} strokeWidth="5"
        strokeDasharray={`${dash} ${circ - dash}`}
        strokeDashoffset={circ * 0.25}
        strokeLinecap="round"
      />
      <text
        x={cx} y={cy + 4}
        textAnchor="middle" fontSize="11" fontWeight="700"
        fill={color} fontFamily="DM Mono, monospace"
      >
        {score}
      </text>
    </svg>
  )
}

// ── Metric Bar ─────────────────────────────────────────────────────
export function MetricBar({ label, value, weight }) {
  const color = value >= 70 ? '#1a9e5c' : value >= 50 ? '#d97706' : '#c0392b'
  return (
    <div className="flex items-center gap-1.5 text-[10px] text-gray-600">
      <span className="w-[68px] shrink-0">{label}</span>
      <div className="flex-1 h-1 bg-gray-100 rounded-full overflow-hidden">
        <div className="h-full rounded-full bar-fill" style={{ width: `${value}%`, background: color }} />
      </div>
      <span className="w-5 text-right font-mono font-medium" style={{ color }}>{value}</span>
      <span className="w-7 text-gray-400 text-[9px]">×{weight}</span>
    </div>
  )
}

// ── Sparkline ─────────────────────────────────────────────────────
export function Sparkline({ history = [], predicted = [] }) {
  const all = [...history, ...predicted]
  const max = Math.max(...all), min = Math.min(...all)
  const norm = (v) => Math.max(8, Math.round(((v - min) / (max - min || 1)) * 40))
  const barColor = (v) => v >= 70 ? '#1a9e5c' : v >= 50 ? '#d97706' : '#c0392b'
  return (
    <div className="flex items-end gap-[3px]" style={{ height: 44 }}>
      {history.map((v, i) => (
        <div key={i} className="spark-bar flex-1 min-w-[6px]"
          style={{ height: norm(v), background: barColor(v) }} title={String(v)} />
      ))}
      {predicted.map((v, i) => (
        <div key={`p${i}`} className="predict-bar flex-1 min-w-[6px]"
          style={{ height: norm(v), background: barColor(v) }} title={`Voorspelling: ${v}`} />
      ))}
    </div>
  )
}

// ── Modal ──────────────────────────────────────────────────────────
export function Modal({ open, onClose, title, headerColor = '#c0392b', children, width = 440 }) {
  useEffect(() => {
    const handler = (e) => e.key === 'Escape' && onClose?.()
    document.addEventListener('keydown', handler)
    return () => document.removeEventListener('keydown', handler)
  }, [onClose])

  if (!open) return null
  return (
    <div
      className="fixed inset-0 z-[200] flex items-center justify-center bg-black/40 backdrop-blur-sm"
      onClick={(e) => e.target === e.currentTarget && onClose?.()}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl overflow-hidden fade-up"
        style={{ width, maxWidth: 'calc(100vw - 40px)' }}
      >
        <div className="flex items-center justify-between px-5 py-4" style={{ background: headerColor }}>
          <div className="text-white text-[13px] font-bold flex items-center gap-2">{title}</div>
          <button onClick={onClose} className="text-white/70 hover:text-white text-xl leading-none bg-transparent border-0 cursor-pointer">
            <X size={18} />
          </button>
        </div>
        <div className="p-5 flex flex-col gap-3">{children}</div>
      </div>
    </div>
  )
}

// ── Drawer ─────────────────────────────────────────────────────────
export function Drawer({ open, onClose, title, subtitle, children }) {
  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-[150] bg-black/35 backdrop-blur-sm overlay-active"
          onClick={onClose}
        />
      )}
      <div
        className="fixed top-0 right-0 bottom-0 w-[420px] bg-white z-[151] overflow-y-auto shadow-2xl"
        style={{ transform: open ? 'translateX(0)' : 'translateX(100%)', transition: 'transform .3s cubic-bezier(.4,0,.2,1)' }}
      >
        <div className="bg-gov px-5 py-5 sticky top-0 z-10">
          <button onClick={onClose} className="absolute top-4 right-4 text-white/70 hover:text-white border-0 bg-transparent cursor-pointer">
            <X size={20} />
          </button>
          <div className="text-white text-[15px] font-bold font-syne">{title}</div>
          {subtitle && <div className="text-white/55 text-[10px] mt-0.5">{subtitle}</div>}
        </div>
        <div className="p-5 flex flex-col gap-4">{children}</div>
      </div>
    </>
  )
}

// ── Toast ──────────────────────────────────────────────────────────
let _setToast = null
export function useToast() {
  return (msg, duration = 3200) => _setToast?.({ msg, duration })
}

export function ToastProvider() {
  const [toast, setToast] = useState(null)
  _setToast = setToast
  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), toast.duration)
    return () => clearTimeout(t)
  }, [toast])

  if (!toast) return null
  return (
    <div className="fixed bottom-6 right-6 z-[300] bg-gov-dark text-white px-4 py-3 rounded-[10px] text-[11px] font-semibold shadow-card-md fade-up max-w-sm">
      {toast.msg}
    </div>
  )
}

// ── Section Header ─────────────────────────────────────────────────
export function SectionHeader({ title, sub, children }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-baseline gap-1.5">
        <span className="text-[13px] font-bold text-gray-900">{title}</span>
        {sub && <span className="text-[11px] text-gray-400">{sub}</span>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  )
}

// ── Detail Row ─────────────────────────────────────────────────────
export function DetailRow({ label, children }) {
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-gray-100 text-[11px]">
      <span className="text-gray-500">{label}</span>
      <span className="font-semibold text-gray-900 text-right max-w-[60%]">{children}</span>
    </div>
  )
}

// ── Bool chip ──────────────────────────────────────────────────────
export function BoolChip({ value, label }) {
  return (
    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${value ? 'bg-green-bg text-green' : 'bg-red-bg text-red'}`}>
      {value ? `✓ ${label}` : `✗ ${label}`}
    </span>
  )
}

// ── Filter buttons ─────────────────────────────────────────────────
export function FilterGroup({ options, active, onChange }) {
  return (
    <div className="flex gap-1">
      {options.map(({ value, label }) => (
        <button
          key={value}
          onClick={() => onChange(value)}
          className={clsx(
            'px-2.5 py-1 rounded-full text-[10px] font-semibold transition-all cursor-pointer border',
            active === value
              ? 'bg-gov text-white border-gov'
              : 'bg-white text-gray-600 border-gray-200 hover:border-gov hover:text-gov'
          )}
        >
          {label}
        </button>
      ))}
    </div>
  )
}

// ── Empty state ────────────────────────────────────────────────────
export function Empty({ message = 'Geen resultaten gevonden.' }) {
  return (
    <div className="py-16 text-center text-gray-400 text-sm col-span-full">{message}</div>
  )
}

// ── Loading skeleton ───────────────────────────────────────────────
export function LoadingGrid({ cols = 2, rows = 3 }) {
  return (
    <div className={`grid grid-cols-${cols} gap-3`}>
      {Array.from({ length: cols * rows }).map((_, i) => (
        <div key={i} className="bg-gray-100 rounded-xl h-40 animate-pulse" />
      ))}
    </div>
  )
}

// ── Input / Select / Textarea ──────────────────────────────────────
export const inputCls = 'w-full px-3 py-2 text-[12px] bg-gray-50 border border-gray-200 rounded-[7px] outline-none focus:border-gov focus:bg-white transition-colors font-sans'

export function Input({ label, ...props }) {
  return (
    <div>
      {label && <div className="text-[9px] uppercase tracking-widest text-gray-400 font-bold mb-1.5">{label}</div>}
      <input className={inputCls} {...props} />
    </div>
  )
}

export function Select({ label, children, ...props }) {
  return (
    <div>
      {label && <div className="text-[9px] uppercase tracking-widest text-gray-400 font-bold mb-1.5">{label}</div>}
      <select className={inputCls} {...props}>{children}</select>
    </div>
  )
}

export function Textarea({ label, ...props }) {
  return (
    <div>
      {label && <div className="text-[9px] uppercase tracking-widest text-gray-400 font-bold mb-1.5">{label}</div>}
      <textarea className={clsx(inputCls, 'resize-y min-h-[90px] leading-relaxed')} {...props} />
    </div>
  )
}
