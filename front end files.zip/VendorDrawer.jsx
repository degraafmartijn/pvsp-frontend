import { Drawer, DetailRow, MetricBar, Sparkline, BoolChip, Badge, Button, ScoreArc } from '@/components/ui'
import { calcScore, rag, RAG_COLOR, fmtEur, daysLeft, predictScore, vName, vEnd, complianceScore, clsx } from '@/lib/utils'
import { useVendor } from '@/hooks/useVendors'

const KM = {
  strategic:  { label: 'Strategisch', color: '#154273', bg: '#e8f0fa' },
  leverage:   { label: 'Hefboom',     color: '#077a8a', bg: '#e0f5f7' },
  bottleneck: { label: 'Knelpunt',    color: '#c0392b', bg: '#fdecea' },
  routine:    { label: 'Routine',     color: '#5c6575', bg: '#f5f5f5' },
}
const LC = {
  onboarding: { label: 'Onboarding', color: '#6d3fc0', bg: '#f0eafb' },
  active:     { label: 'Actief',     color: '#1a9e5c', bg: '#eaf7f1' },
  renewal:    { label: 'Renewal',    color: '#d97706', bg: '#fef3e0' },
  exit:       { label: 'Exit',       color: '#c0392b', bg: '#fdecea' },
}

function Section({ title, children }) {
  return (
    <div>
      <div className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-2.5 pb-1 border-b border-gray-100">{title}</div>
      {children}
    </div>
  )
}

export default function VendorDrawer({ vendorId, onClose, onPlaybook }) {
  const { data: vendor, isLoading } = useVendor(vendorId)
  const open = !!vendorId

  if (!open) return null

  const h = vendor
    ? { c: vendor.health_score ?? 50, p: 50, a: 50, s: 50 } // fallback until metrics load
    : {}

  // Use latest health metric if available
  const metrics = vendor?.health_metrics || []
  const latest  = metrics[0]
  const hData   = latest ? { c: latest.compliance, p: latest.performance, a: latest.adoption, s: latest.sentiment } : h

  const score   = vendor?.health_score ?? calcScore(hData)
  const r       = rag(score)
  const km      = KM[vendor?.kraljic_category] || KM.routine
  const lc      = LC[vendor?.lifecycle_stage]  || LC.active
  const endDate = vendor ? vEnd(vendor) : null
  const days    = endDate ? daysLeft(endDate) : null

  const history   = metrics.slice(0, 7).reverse().map(m => calcScore({ c: m.compliance, p: m.performance, a: m.adoption, s: m.sentiment }))
  const histFull  = history.length >= 3 ? history : [score, score, score]
  const predicted = predictScore(histFull)

  const c = vendor?.compliance
  const compScore = c ? complianceScore(c) : null

  const vd = vendor?.vendor_domains?.[0]

  return (
    <Drawer
      open={open}
      onClose={onClose}
      title={vendor ? vName(vendor) : '…'}
      subtitle={vendor ? `${km.label} · ${lc.label} · ${score >= 70 ? 'Gezond' : score >= 50 ? 'Waarschuwing' : 'Kritiek'}` : ''}
    >
      {isLoading && (
        <div className="py-16 text-center text-gray-400">Laden…</div>
      )}

      {vendor && (
        <>
          {/* VHS Score */}
          <Section title="VHS Score & Trend">
            <div className="bg-gray-50 rounded-xl p-3.5">
              <div className="flex items-center justify-between mb-3">
                <span className="text-[12px] font-bold text-gray-900">Vendor Health Score</span>
                <span className="text-[26px] font-black font-syne" style={{ color: RAG_COLOR[r] }}>{score}</span>
              </div>
              <div className="flex flex-col gap-1.5">
                <MetricBar label="Compliance"  value={hData.c} weight="35%" />
                <MetricBar label="Performance" value={hData.p} weight="35%" />
                <MetricBar label="Adoptie"     value={hData.a} weight="20%" />
                <MetricBar label="Sentiment"   value={hData.s} weight="10%" />
              </div>
              <div className="mt-3">
                <div className="text-[9px] text-gray-400 uppercase tracking-wider mb-1">7 periodes + 3 voorspeld</div>
                <Sparkline history={histFull} predicted={predicted} />
              </div>
            </div>
          </Section>

          {/* Leverancier_record */}
          <Section title="Leverancier Record">
            <DetailRow label="Statutaire naam">{vendor.legal_name}</DetailRow>
            <DetailRow label="Handelsnaam">{vendor.trade_name || '–'}</DetailRow>
            <DetailRow label="KvK-nummer"><span className="font-mono">{vendor.kvk_number}</span></DetailRow>
            <DetailRow label="Btw-nummer"><span className="font-mono text-[10px]">{vendor.tax_id || '–'}</span></DetailRow>
            <DetailRow label="IBAN"><span className="font-mono text-[10px]">{vendor.iban || '–'}</span></DetailRow>
            <DetailRow label="Website">
              {vendor.website ? <a href={vendor.website} target="_blank" rel="noreferrer" className="text-gov text-[10px]">{vendor.website.replace('https://','')}</a> : '–'}
            </DetailRow>
            <DetailRow label="E-mail"><span className="text-[10px]">{vendor.general_email || '–'}</span></DetailRow>
            <DetailRow label="Telefoon"><span className="font-mono">{vendor.phone_main || '–'}</span></DetailRow>
            <DetailRow label="HQ Adres"><span className="text-[10px]">{vendor.address_hq || '–'}</span></DetailRow>
            <DetailRow label="Risicoprofiel">
              <Badge
                color={vendor.risk_level === 'hoog' ? '#c0392b' : vendor.risk_level === 'medium' ? '#d97706' : '#1a9e5c'}
                bg={vendor.risk_level === 'hoog' ? '#fdecea' : vendor.risk_level === 'medium' ? '#fef3e0' : '#eaf7f1'}
              >
                {vendor.risk_level || '–'}
              </Badge>
            </DetailRow>
            <DetailRow label="Betaaltermijn">{vendor.payment_terms || '–'}</DetailRow>
            <DetailRow label="Kredietwaardigheid"><span className="text-[10px]">{vendor.credit_rating || '–'}</span></DetailRow>
          </Section>

          {/* Rollen */}
          <Section title="Rollen">
            <DetailRow label="Account Manager">{vendor.account_manager || '–'}</DetailRow>
            <DetailRow label="Interne Beheerder">{vendor.internal_owner || '–'}</DetailRow>
            <DetailRow label="Product Owner">{vendor.product_owner || '–'}</DetailRow>
            <DetailRow label="Categorie (Kraljic)"><Badge color={km.color} bg={km.bg}>{km.label}</Badge></DetailRow>
            <DetailRow label="Lifecycle Fase"><Badge color={lc.color} bg={lc.bg}>{lc.label}</Badge></DetailRow>
          </Section>

          {/* Domein_record */}
          {vd && (
            <Section title="Domein Record">
              <DetailRow label="Domein">{vendor.vendor_domains?.[0]?.domain_name || '–'}</DetailRow>
              <DetailRow label="Bekostigingsmodel"><span className="text-[10px]">{vd.bekostigingsmodel || '–'}</span></DetailRow>
              <DetailRow label="AGB-code"><span className="font-mono">{vd.agb_code || '–'}</span></DetailRow>
              <DetailRow label="Indexering"><span className="text-[10px]">{vd.indexering || '–'}</span></DetailRow>
              <DetailRow label="Evaluatiedatum">{vd.evaluatiedatum || '–'}</DetailRow>
              <DetailRow label="VGB Check"><BoolChip value={vd.vgb_check} label="Afgerond" /></DetailRow>
            </Section>
          )}

          {/* compliance_record */}
          {c && (
            <Section title={`Compliance Record · ${compScore}%`}>
              <div className="grid grid-cols-2 gap-1.5 mb-2">
                <BoolChip value={c.nis2_compliant}       label={`NIS2 (${c.nis2_category || '–'})`} />
                <BoolChip value={c.gibit_applicable}     label={`GIBIT ${c.gibit_version || ''}`} />
                <BoolChip value={c.bio_compliant}        label={`BIO ${c.bio_classification || ''}`} />
                <BoolChip value={c.iso_27001_certified}  label={`ISO 27001 (${c.iso_27001_version || '–'})`} />
                <BoolChip value={c.iso_9001_certified}   label="ISO 9001" />
                <BoolChip value={c.soc2_report}          label="SOC2 Type II" />
                <BoolChip value={c.dpia_performed}       label="DPIA" />
                <BoolChip value={c.gdpr_agreement}       label="Verwerkersovk." />
              </div>
              <DetailRow label="Laatste Audit">
                <span className={c.last_audit_date && new Date(c.last_audit_date) < new Date(Date.now() - 365*86400000) ? 'text-amber' : ''}>
                  {c.last_audit_date || '–'}
                </span>
              </DetailRow>
            </Section>
          )}

          {/* Adoptie */}
          {vendor.licensed_users && (
            <Section title="Adoptie">
              <DetailRow label="Actieve gebruikers">{vendor.active_users?.toLocaleString('nl-NL')} / {vendor.licensed_users?.toLocaleString('nl-NL')}</DetailRow>
              <DetailRow label="Adoptiegraad">
                <span style={{ color: vendor.adoption_rate >= 70 ? '#1a9e5c' : vendor.adoption_rate >= 50 ? '#d97706' : '#c0392b', fontWeight: 700 }}>
                  {vendor.adoption_rate}%
                </span>
              </DetailRow>
            </Section>
          )}

          {/* contract_record */}
          {vendor.contracts?.length > 0 && (
            <Section title={`Contracten (${vendor.contracts.length})`}>
              {vendor.contracts.map(ct => (
                <div key={ct.id} className="bg-gray-50 rounded-xl p-3 mb-2 border border-gray-100">
                  <div className="flex justify-between items-start gap-2 mb-2">
                    <div>
                      <div className="text-[11px] font-bold text-gray-900">{ct.contract_name}</div>
                      <div className="text-[9px] text-gray-400 mt-0.5">{ct.contract_id} · {ct.legal_entity}</div>
                    </div>
                    <Badge
                      color={ct.status === 'active' ? '#1a9e5c' : ct.status === 'renewal' ? '#d97706' : ct.status === 'verlopen' ? '#c0392b' : '#9aa3b0'}
                      bg={ct.status === 'active' ? '#eaf7f1' : ct.status === 'renewal' ? '#fef3e0' : ct.status === 'verlopen' ? '#fdecea' : '#f5f5f5'}
                    >
                      {ct.status}
                    </Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-y-1 text-[10px] text-gray-600">
                    <div>Type: <strong>{ct.contract_type}</strong></div>
                    <div>Waarde: <strong className="font-mono">{fmtEur(ct.total_value)}</strong></div>
                    <div>Start: <strong>{ct.start_date}</strong></div>
                    <div>Einde: <strong className={daysLeft(ct.end_date) <= 90 ? 'text-red' : ''}>{ct.end_date}</strong></div>
                    <div>Opzegtermijn: <strong>{ct.notice_period}d</strong></div>
                    <div>Jaarwaarde: <strong className="font-mono">{ct.annual_value ? fmtEur(ct.annual_value) : '–'}</strong></div>
                    <div>Verlenging: <strong>{ct.renewal_type}</strong></div>
                    <div><BoolChip value={ct.signature_status} label="Getekend" /></div>
                  </div>
                </div>
              ))}
            </Section>
          )}

          {/* Playbook trigger */}
          {score < 50 && (
            <button
              onClick={() => onPlaybook?.(vendor)}
              className="w-full flex items-center justify-center gap-1.5 bg-red text-white text-[10px] font-bold py-2 rounded-lg hover:bg-red-700 transition-colors pulse-red cursor-pointer border-0 mt-2"
            >
              Score Kritiek – Start Playbook
            </button>
          )}
        </>
      )}
    </Drawer>
  )
}
