import { Search, Bell, Plus } from 'lucide-react'
import { useNavigate, useLocation } from 'react-router-dom'
import { useSummary } from '@/hooks/useVendors'
import { Button } from '@/components/ui'

const PAGE_TITLES = {
  '/dashboard':  'Dashboard',
  '/manager':    'Manager Dashboard',
  '/vendors':    'Leveranciers',
  '/renewal':    'Renewal Funnel',
  '/tasks':      'Taken & Playbooks',
  '/governance': 'Overlegmatrix',
  '/risklog':    'Risk Log',
  '/aitools':    'AI Gereedschappen',
  '/alerts':     'Meldingen',
  '/analytics':  'Portfolio Analyse',
}

export default function Topbar({ search, setSearch, onNewTask }) {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { data: summary } = useSummary()
  const crit = summary?.critical_count || 0

  return (
    <header className="bg-white border-b border-gray-200 px-7 py-3 flex items-center gap-4 sticky top-0 z-50">
      <div>
        <div className="font-syne text-[15px] font-extrabold text-gray-900">
          {PAGE_TITLES[pathname] || 'PVSP'}
        </div>
        <div className="text-[10px] text-gray-400 mt-0.5">Vendor Lifecycle Management · Rijksoverheid</div>
      </div>

      {/* Search */}
      <div className="relative flex-1 max-w-[240px] ml-4">
        <Search size={11} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Zoek leverancier…"
          className="w-full pl-7 pr-3 py-1.5 text-[11px] bg-gray-100 border border-gray-200 rounded-[7px] outline-none focus:border-gov focus:bg-white transition-colors"
        />
      </div>

      <div className="ml-auto flex items-center gap-2">
        {crit > 0 && (
          <div className="flex items-center gap-1.5 bg-red-bg border border-red/30 text-red text-[10px] font-semibold px-3 py-1 rounded-full">
            <AlertTriangle size={10} />
            {crit} kritieke leverancier{crit !== 1 ? 's' : ''}
          </div>
        )}

        <Button size="sm" variant="primary" onClick={onNewTask} className="gap-1">
          <Plus size={11} /> Taak aanmaken
        </Button>

        <button
          onClick={() => navigate('/alerts')}
          className="w-8 h-8 rounded-[7px] border border-gray-200 bg-white flex items-center justify-center text-gray-400 hover:border-gov hover:text-gov transition-all cursor-pointer relative"
        >
          <Bell size={14} />
          {crit > 0 && (
            <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-red rounded-full border border-white" />
          )}
        </button>
      </div>
    </header>
  )
}

function AlertTriangle({ size }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
    </svg>
  )
}
